# SEYYAH

Dünyayı, kıtaları, ülkeleri ve şehirleri keşfettikçe işaretleyin; dünyanın,
bir kıtanın veya bir ülkenin yüzde kaçını gezdiğinizi anında görün.

Bu depo, SEYYAH'ın **tam Flutter (Dart) kaynak kodunu** içerir — hem
Android (Google Play) hem de iOS (App Store) için tek bir kod tabanından
derlenebilecek şekilde yazılmıştır.

---

## 0) Bu projeyi teslim alırken bilmeniz gerekenler

Bu kod, ağ erişimi ve Flutter SDK'sı kurulu OLMAYAN bir bulut ortamında
hazırlandı. Bu yüzden:

- **Kod burada derlenip test edilmedi.** Elinizdeki kaynak kod eksiksiz ve
  standart Flutter mimarisine uygun yazılmıştır, ancak `flutter run` ile
  ilk açılışta küçük paket-sürümü uyumsuzlukları çıkması olağandır (bkz.
  §4 "Bilinen riskler").
- **Şehir veri seti, GeoNames gibi büyük kaynaklardan indirilemediği için
  elle derlenmiş bir BAŞLANGIÇ veri setidir** (199 ülke/bölge, ~1000
  şehir — her ülkenin başkenti + bilinen başlıca şehirleri). Daha
  kapsamlı, resmi bir veri setiyle genişletmek için §5'e bakın.
- **Google Play / App Store'a fiili yayınlama sizin tarafınızdan
  yapılmalı** (geliştirici hesabı, imzalama anahtarı, mağaza incelemesi).
  §6 ve §7'de adım adım rehber var.
- **Bilgisayarınıza Flutter kurmak istemiyorsanız:** Proje kökündeki
  `codemagic.yaml`, [codemagic.io](https://codemagic.io) gibi ücretsiz bir
  bulut derleme servisine bu depoyu bağladığınızda Android APK/AAB ve
  (Apple hesabınızı tanımladıktan sonra) iOS IPA dosyasını sizin için
  derler — kendi bilgisayarınıza hiçbir şey kurmanız gerekmez.
- **Gizlilik politikası hazır ve yayında:**
  https://claude.ai/artifact/CQWRLCoPHdZhxt44Z79gzb — Play Console ve
  App Store Connect'e gönderirken bu URL'yi kullanabilirsiniz (yalnızca
  "Bu sayfa herkese açık" olacak şekilde paylaşıldığından emin olun,
  aksi halde mağaza incelemesi sayfayı açamaz).

---

## 0.5) Gerçek e-posta doğrulaması (Firebase + EmailJS) kurulumu — GEREKLİ

Giriş ekranı artık gerçek bir doğrulama kodu e-postayla gönderir (demo modu
kaldırıldı). Bunu çalıştırmak için **ikisi de ücretsiz, kredi kartı
istemeyen** iki hesap açmanız gerekiyor. Kod, `lib/services/
email_verification_service.dart` içinde zaten yazılı; sizin yapmanız
gereken tek şey aşağıdaki anahtarları `lib/config/backend_config.dart`
dosyasına yapıştırmak.

**Neden "Firebase Authentication" değil?** Firebase'in kendi "Authentication"
ürünü, e-postaya 6 haneli bir KOD gönderme yöntemi sunmuyor (yalnızca
parola veya "e-postana bir BAĞLANTI gönder" yöntemi var, o da artık kendi
alan adınızı gerektiren bir kurulum istiyor). Bunun yerine, istediğiniz
"kodu e-postana gönder" akışını Firebase'in ücretsiz Firestore veritabanı
+ ücretsiz EmailJS servisiyle kurduk — sonuç birebir aynı kullanıcı
deneyimi, tamamen ücretsiz.

### Adım 1 — Firebase projesi ve Firestore

1. https://console.firebase.google.com adresine gidip Google hesabınızla
   yeni bir proje oluşturun (ücretsiz "Spark" plan yeterli, kredi kartı
   istemez).
2. Sol menüden **Firestore Database** > **Create database** ile bir
   veritabanı oluşturun (konum olarak size yakın bir bölge seçin, "Start
   in production mode" seçin).
3. **Rules** sekmesine gidip proje köküdeki `firestore.rules` dosyasının
   TÜM içeriğini yapıştırın ve **Publish** deyin.
4. Proje ayarlarına (dişli simgesi > **Project settings**) gidip "Your
   apps" altında **</>** (Web) simgesine tıklayarak bir web uygulaması
   kaydedin (isim önemli değil, "Firebase Hosting" kutucuğunu
   işaretlemenize gerek yok).
5. Karşınıza çıkan `firebaseConfig` nesnesindeki değerleri
   `lib/config/backend_config.dart` içindeki ilgili alanlara kopyalayın
   (`apiKey`, `appId`, `messagingSenderId`, `projectId`, `authDomain`,
   `storageBucket`).

### Adım 2 — EmailJS (e-postayı gerçekten göndermek için)

1. https://www.emailjs.com adresinde ücretsiz bir hesap açın (ayda 200
   e-posta sınırı, kredi kartı istemez).
2. **Email Services** > **Add New Service** ile kendi Gmail/Outlook
   hesabınızı (veya benzeri bir sağlayıcıyı) bağlayın; oluşan
   **Service ID**'yi not edin.
3. **Email Templates** > **Create New Template** ile yeni bir şablon
   oluşturun. Şablonun içeriğine şunun gibi bir metin yazın (değişken
   isimleri BİREBİR aynı olmalı):
   ```
   Konu: SEYYAH doğrulama kodun

   Merhaba {{name}},

   SEYYAH'a giriş yapmak için doğrulama kodun: {{code}}

   Bu kodu istemediysen bu e-postayı yok sayabilirsin.
   ```
   "To email" alanına `{{to_email}}` yazmayı unutmayın. Kaydedince
   **Template ID**'yi not edin.
4. Sol menüden **Account** > **General** sekmesindeki **Public Key**'i
   not edin.
5. Bu üç değeri (`emailJsServiceId`, `emailJsTemplateId`,
   `emailJsPublicKey`) `lib/config/backend_config.dart` dosyasına
   yapıştırın.

Bu iki adımı tamamlayıp `flutter pub get` çalıştırdıktan sonra giriş
ekranı gerçek e-posta gönderir. Doldurmadan uygulamayı çalıştırırsanız
giriş ekranı bunu algılar ve "geliştirici ayarları eksik" uyarısı
gösterir — uygulamanın geri kalanı (kıta/ülke/şehir listeleri) bundan
ETKİLENMEZ.

**Güvenlik notu:** Doğrulama kodu, Firestore güvenlik kuralları
sayesinde istemciye hiçbir zaman okutulmaz (bkz. `firestore.rules`
içindeki açıklama) — bu iyi bir temel güvenliktir ama banka uygulaması
seviyesinde değildir (ör. deneme sayısı sınırı yoktur). Bir seyahat
takip uygulaması için yeterlidir.

**Mağaza formları için önemli:** E-posta adresi artık cihaz dışına
(Firestore + EmailJS'e) gönderiliyor. Play Console'daki "Data safety"
ve App Store Connect'teki "App Privacy" formlarını buna göre
güncelleyin — `store/play_store/` ve `store/app_store/` klasörlerindeki
notlara bakın; gizlilik politikası (`store/privacy_policy/
privacy_policy_tr.md` ve yayınlanmış hali) bu değişikliği zaten
yansıtıyor.

---

## 1) Proje Yapısı

```
seyyah/
  lib/
    main.dart                  # Uygulama giriş noktası
    app.dart                   # MaterialApp + tema kurulumu
    theme/app_theme.dart       # Kırmızı/beyaz marka teması
    models/                    # Continent, Country, City veri modelleri
    data/database_helper.dart  # SQLite şeması + seed (ilk veri yükleme)
    services/
      stats_service.dart           # Yüzde hesap mantığı
      geo_boundaries_service.dart  # Harita sınır verisini indirir/önbelgekler
    providers/travel_provider.dart # Uygulama geneli durum yönetimi (Provider)
    screens/                   # Splash, Home, Continent, Country, Map, Settings, About
    widgets/                   # Yeniden kullanılabilir UI bileşenleri
  assets/
    data/*.json                # Kıta/ülke/şehir başlangıç verisi
    images/
      seyyah_logo_lockup.png   # Marka logosu (ikon + "SEYYAH" yazısı, splash ekranı)
      seyyah_logo_icon.png     # Marka logosu (yalnızca ikon, Hakkında ekranı)
      app_icon_1024.png            # Uygulama ikonu (düz, iOS)
      app_icon_foreground_1024.png # Android adaptive iconön katmanı (şeffaf)
      splash_logo.png              # flutter_native_splash görseli
      continents/*.png          # Her kıta için "pop art" rozet görseli
  tools/
    generate_data.py           # continents/countries/cities.json üretici
    import_geonames.py         # GeoNames'ten şehir verisi İÇE AKTARMA aracı
  store/
    privacy_policy/            # Gizlilik politikası taslağı (TR)
    play_store/                # Google Play mağaza metinleri (TR)
    app_store/                 # Apple App Store mağaza metinleri (TR)
  pubspec.yaml
```

## 2) Mimari Özeti

- **Veri katmanı:** `assets/data/*.json` içindeki kıta/ülke/şehir verisi,
  uygulama ilk açıldığında bir SQLite veritabanına (`sqflite`) "seed"
  edilir. Kullanıcının "gezildi" işaretlemeleri bu veritabanında saklanır
  ve kalıcıdır.
- **Yüzde hesabı (sayı bazlı):**
  ```
  yüzde = (gezilen şehir sayısı / toplam şehir sayısı) × 100
  ```
  Bu mantık ülke, kıta ve dünya seviyelerinde TUTARLI biçimde uygulanır:
  bir kıtanın yüzdesi, o kıtadaki TÜM ülkelerin şehirleri toplamı
  üzerinden hesaplanır; dünya yüzdesi de aynı şekilde tüm şehirler
  toplamı üzerinden hesaplanır. Bkz. `lib/services/stats_service.dart`.
- **Gezinme:** Dünya (Ana ekran) → Kıta → Ülke → Şehir. Her seviyede o
  seviyenin toplam/gezilen şehir sayısı ve yüzdesi gösterilir.
- **Harita:** `MapScreen`, ülke sınırlarını UYGULAMA ÇALIŞIRKEN (kullanıcının
  cihazında, bu geliştirme ortamında değil) Natural Earth'ten indirip
  cihaza önbelgekler ve `flutter_map` ile boyayarak gösterir. İnternet
  yoksa harita nazikçe devre dışı kalır; listeler ve yüzde hesapları
  BUNDAN ETKİLENMEZ.
- **Durum yönetimi:** `provider` paketi ile basit bir `ChangeNotifier`
  (`TravelProvider`).

## 3) Kurulum ve Çalıştırma (kendi bilgisayarınızda)

Gereksinimler: [Flutter SDK](https://docs.flutter.dev/get-started/install)
(3.22+ önerilir), Android Studio veya Xcode (ilgili platform için).

```bash
cd seyyah
flutter pub get
flutter run
```

İlk çalıştırmada `flutter create .` komutuna GEREK YOKTUR — `android/`
ve `ios/` platform klasörleri bu depoda YOKTUR (bkz. §4). Önce şu adımı
uygulayın:

```bash
# Proje kökünde, android/ ve ios/ klasörlerini oluşturmak için:
flutter create --project-name seyyah --org com.roipublic .
```

Bu komut `android/`, `ios/`, `web/`, `linux/`, `macos/`, `windows/`
klasörlerini ekler; MEVCUT `lib/`, `pubspec.yaml` ve `assets/`
dosyalarınıza DOKUNMAZ (Flutter, var olan bu dosyaları korur). Komut
bittikten sonra:

```bash
flutter pub get

# Uygulama ikonlarını üret (pubspec.yaml'daki flutter_launcher_icons
# yapılandırmasını kullanır):
dart run flutter_launcher_icons

# Açılış ekranını (splash) üret:
dart run flutter_native_splash:create

flutter run
```

## 4) Bilinen Riskler / Kontrol Listesi

Bu kod bu ortamda derlenemediği için, `flutter pub get` sonrası olası
küçük sorunlar ve çözümleri:

- **Paket sürüm çakışması:** `flutter pub get` bir sürüm çözemezse,
  `pubspec.yaml`'daki ilgili paketin sürümünü `flutter pub outdated`
  çıktısına göre güncelleyin (`^` operatörü zaten esnek aralık tanımlar).
- **`flutter_map` API'si:** `lib/screens/map_screen.dart` içinde
  `PolygonLayer<String>` ve `hitNotifier` kullanımı, flutter_map 7.x
  API'sine göre yazılmıştır. Kurduğunuz sürüm farklıysa, paketin
  [migration rehberine](https://pub.dev/packages/flutter_map) bakarak
  `Polygon`/`PolygonLayer` çağrılarını güncelleyin. Bu ekran isteğe
  bağlı bir GÖRSEL katmandır; derleme hatası verirse geçici olarak
  `MapScreen`'i `HomeScreen`'deki harita butonundan kaldırıp devam
  edebilirsiniz — uygulamanın geri kalanı etkilenmez.
- **Natural Earth URL'si erişilemez olabilir:** Kurumsal ağlarda
  `raw.githubusercontent.com` engelli olabilir. `lib/services/
  geo_boundaries_service.dart` içindeki `naturalEarthUrls` listesine
  kendi barındırdığınız bir GeoJSON URL'si ekleyin/değiştirin.
- **iOS imzalama:** `flutter create` sonrası Xcode'da bundle identifier
  ve "Signing & Capabilities" bölümünden kendi Apple geliştirici
  hesabınızı seçmeniz gerekir.
- **Trebuchet MS fontu (lisans notu):** Trebuchet MS, Microsoft'un
  tescilli bir fontudur ve uygulama paketi içine yeniden dağıtılamaz.
  `lib/theme/app_theme.dart` içinde `fontFamily: 'Trebuchet MS'` olarak
  ayarlanmıştır: iOS bu fontu sistemde hazır bulundurduğu için orada
  gerçek Trebuchet MS görünür; Android'de ise bu isimde bir font kurulu
  olmadığından Flutter otomatik olarak sistem varsayılanına (Roboto)
  geri döner. Android'de de birebir Trebuchet MS görünümü istiyorsanız,
  metrik uyumlu ücretsiz bir alternatifi `assets/fonts/` altına ekleyip
  `pubspec.yaml`'da tanımlamanız ve `app_theme.dart`'taki `fontFamily`
  sabitini o fontun ailesine çevirmeniz gerekir.
- **Kıta rozet görselleri:** `assets/images/continents/*.png` dosyaları,
  bu ortamda (internet erişimi ve tasarım araçları olmadan) Pillow ile
  üretilmiş, kıtaları temsil eden basitleştirilmiş "pop art" tarzı
  ikonlardır (üretici script: bkz. proje geçmişi). Daha kesin coğrafi
  siluetler veya profesyonel bir illüstrasyon isterseniz bu 7 dosyayı
  aynı isimlerle (AF/AS/EU/NA/SA/OC/AN.png, kare, tercihen şeffaf veya
  daire zeminli) değiştirmeniz yeterlidir; kodda başka bir değişiklik
  gerekmez.

## 5) Şehir Veri Setini Genişletme (GeoNames ile)

Mevcut `assets/data/cities.json` ~1000 şehir içerir (bkz. proje
tanımındaki kapsam notu). Çok daha kapsamlı, resmi bir veri setiyle
genişletmek için:

1. https://download.geonames.org/export/dump/ adresinden bir döküm indirin
   (ör. `cities15000.zip` — nüfusu ≥15.000 olan ~25 bin şehir, ya da
   `cities5000.zip` / `cities1000.zip` daha kapsamlı listeler için).
2. Zip'i açın.
3. Çalıştırın:
   ```bash
   python3 tools/import_geonames.py /yol/cities15000.txt \
       --min-population 20000 --max-per-country 60
   ```
4. **ÖNEMLİ:** `lib/data/database_helper.dart` içindeki
   `_seedDataVersion` sabitini artırın (`'1'` → `'2'`), aksi halde
   uygulamayı zaten yüklemiş kullanıcıların cihazlarındaki veritabanı
   yeni şehirleri görmez (bu, mevcut kullanıcıların "gezildi"
   işaretlerinin KORUNMASI için bilinçli bir tasarım kararıdır — seed
   işlemi asla var olan bir satırın üzerine yazmaz, sadece eksik olanı
   ekler).

GeoNames verisi CC BY 4.0 lisanslıdır; mağaza açıklamanıza veya
uygulama içi "Hakkında" ekranına "Şehir verileri: GeoNames.org (CC BY
4.0)" şeklinde bir atıf eklemeniz önerilir.

## 6) Android için Build & Google Play Yayınlama

```bash
# İmzalama anahtarı oluşturun (ilk sefer):
keytool -genkey -v -keystore ~/seyyah-release.jks -keyalg RSA \
    -keysize 2048 -validity 10000 -alias seyyah

# android/key.properties dosyası oluşturun ve android/app/build.gradle
# içinde signingConfigs.release olarak referans verin
# (bkz. https://docs.flutter.dev/deployment/android)

flutter build appbundle --release
```

Çıktı: `build/app/outputs/bundle/release/app-release.aab`. Bu dosyayı
[Google Play Console](https://play.google.com/console)'da yeni bir
uygulama oluşturup yüklersiniz. Mağaza metinleri için
`store/play_store/play_store_listing_tr.md`, gizlilik politikası için
`store/privacy_policy/privacy_policy_tr.md` dosyalarını kullanın.

## 7) iOS için Build & App Store Yayınlama

Bir Mac ve Apple Developer Program üyeliği ($99/yıl) gereklidir.

```bash
flutter build ipa --release
```

Ardından Xcode > Window > Organizer üzerinden veya
`xcrun altool` / Transporter uygulamasıyla App Store Connect'e
yükleyin. Mağaza metinleri için `store/app_store/app_store_listing_tr.md`
dosyasını kullanın.

## 8) Yol Haritası Önerileri (opsiyonel, sonraki sürümler için)

- Çoklu dil desteği (İngilizce) — `flutter_localizations` + `.arb` dosyaları.
- Bulut yedekleme / cihazlar arası senkronizasyon (ör. Firebase).
- Ülke bayrağı yerine gerçek bayrak görselleri (emoji yerine SVG bayrak seti).
- Şehir bazında ziyaret tarihi/fotoğraf/not ekleme.
- Widget desteği (ana ekran widget'ı ile hızlı ilerleme görünümü).

## Lisans / Atıflar

- Ülke sınırları: [Natural Earth](https://www.naturalearthdata.com) (kamu malı).
- Genişletilmiş şehir verisi (opsiyonel): [GeoNames.org](https://www.geonames.org) (CC BY 4.0).
- Marka rengi, yaygın bir "Türk kırmızısı" (Türk bayrağı kırmızısına
  yakın) tonudur; SEYYAH logosu özgün bir tasarımdır ve herhangi bir
  üçüncü taraf markasının kopyası değildir.
