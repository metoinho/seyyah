import 'package:flutter/material.dart';

import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';
import 'utils/constants.dart';

class SeyyahApp extends StatelessWidget {
  const SeyyahApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      // Uygulama şimdilik Türkçe; ileride flutter_localizations eklenerek
      // çoklu dil desteğine genişletilebilir (bkz. README).
      locale: const Locale('tr', 'TR'),
      home: const SplashScreen(),
    );
  }
}
