import 'package:firebase_core/firebase_core.dart';

/// SEYYAH giriş ekranının GERÇEK e-posta doğrulama koduna geçmesi için
/// gereken tüm dış servis ayarları burada toplanmıştır.
///
/// Neden "Firebase Authentication" değil de Firestore + EmailJS?
/// -----------------------------------------------------------------
/// Firebase'in kendi "Authentication" ürünü hazır bir "e-postaya 6 haneli
/// kod gönder" yöntemi SUNMAZ (yalnızca parola, telefon/SMS veya "e-postana
/// bir bağlantı gönder, ona tıkla" yöntemlerini sunar — ikincisi artık
/// Firebase'in kapattığı "Dynamic Links" alt yapısına ihtiyaç duyuyor ve
/// kendi alan adınızı gerektiriyor). SEYYAH'ın istediği "kodu e-postana
/// gönder, sen gir" akışını ÜCRETSİZ ve kredi kartı istemeden kurmak için:
///   • Kod, Firebase'in ÜCRETSİZ Firestore veritabanında saklanır,
///   • Kodu içeren e-posta, ÜCRETSİZ EmailJS servisiyle gönderilir.
/// Bu, tamamen gerçek ve ücretsizdir; yalnızca "Firebase Authentication"
/// SDK'sının kendisi değil, Firebase'in Firestore ürünüdür.
///
/// AŞAĞIDAKİ TÜM "TODO" DEĞERLERİ SİZİN DOLDURMANIZ GEREKİR — bunlar
/// hesabınıza özel, benim üretemeyeceğim anahtarlardır. Nereden
/// alınacakları için proje kökündeki README.md'nin "Gerçek e-posta
/// doğrulaması (Firebase + EmailJS) kurulumu" bölümüne bakın.
class BackendConfig {
  BackendConfig._();

  // --- 1) Firebase (Firestore) ayarları ---
  // Firebase Console > Project settings > General > "Your apps" > Web app
  // (</>) simgesiyle eklediğiniz uygulamanın "firebaseConfig" nesnesinden
  // kopyalayın. Web app kaydı yeterlidir; ayrı Android/iOS app eklemenize
  // GEREK YOKTUR (google-services.json / GoogleService-Info.plist gerekmez).
  static const _firebaseOptions = FirebaseOptions(
    apiKey: 'TODO_FIREBASE_API_KEY',
    appId: 'TODO_FIREBASE_APP_ID',
    messagingSenderId: 'TODO_FIREBASE_MESSAGING_SENDER_ID',
    projectId: 'TODO_FIREBASE_PROJECT_ID',
    authDomain: 'TODO_FIREBASE_PROJECT_ID.firebaseapp.com',
    storageBucket: 'TODO_FIREBASE_PROJECT_ID.appspot.com',
  );

  static FirebaseOptions get firebaseOptions => _firebaseOptions;

  static bool get isFirebaseConfigured =>
      !_firebaseOptions.apiKey.startsWith('TODO_');

  // --- 2) EmailJS ayarları ---
  // https://www.emailjs.com üzerinde ücretsiz hesap açıp bir "Email
  // Service" (ör. kendi Gmail'iniz) ve bir "Email Template" oluşturunca
  // bu üç değeri Account > General sekmesinden ve ilgili servis/şablon
  // sayfalarından kopyalayın. Şablonda mutlaka {{to_email}}, {{name}} ve
  // {{code}} adında değişkenler kullanın (bkz. README).
  static const emailJsServiceId = 'TODO_EMAILJS_SERVICE_ID';
  static const emailJsTemplateId = 'TODO_EMAILJS_TEMPLATE_ID';
  static const emailJsPublicKey = 'TODO_EMAILJS_PUBLIC_KEY';

  static bool get isEmailJsConfigured =>
      !emailJsServiceId.startsWith('TODO_') &&
      !emailJsTemplateId.startsWith('TODO_') &&
      !emailJsPublicKey.startsWith('TODO_');
}
