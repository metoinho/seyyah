import 'dart:async';
import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

/// SEYYAH'ın tüm kalıcı verisini yöneten tekil (singleton) veritabanı katmanı.
///
/// Şema:
///   continents(id, name_tr, name_en, emoji)
///   countries(id, name_tr, name_en, continent_id, capital, flag)
///   provinces(id, name, country_id, is_capital)
///   cities(id, seed_key, name, country_id, is_capital, visited, province_id)
///   meta(key, value)
///
/// `provinces`, bazı ülkelerde (şu an yalnızca Türkiye) ülke ile şehir
/// arasına giren bir ara katmandır: Türkiye -> il -> ilçe. Bir ülkenin
/// `provinces` satırı yoksa (provincesFor sonucu boşsa) o ülke eskisi gibi
/// doğrudan düz şehir listesiyle gösterilir.
///
/// Ülke/kıta/il/şehir verisi `assets/data/*.json` dosyalarından tek seferlik
/// olarak (seed) veritabanına yüklenir. Kullanıcının "ziyaret edildi"
/// işaretlemeleri veritabanında saklanır ve uygulama güncellemelerinde
/// (veri seti genişlese bile) KORUNUR — seed işlemi yalnızca eksik satırları
/// ekler, var olanların `visited` durumuna dokunmaz.
class DatabaseHelper {
  DatabaseHelper._internal();
  static final DatabaseHelper instance = DatabaseHelper._internal();

  static const _dbName = 'seyyah.db';
  static const _dbVersion = 2;

  // Bu değeri artırıp assets/data/*.json güncellendiğinde, uygulama bir
  // sonraki açılışta yeni il/şehir/ülke satırlarını mevcut verinin üzerine
  // (ziyaret durumlarını bozmadan) ekler.
  static const _seedDataVersion = '3';

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, _dbName);

    final db = await openDatabase(
      path,
      version: _dbVersion,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE continents (
            id TEXT PRIMARY KEY,
            name_tr TEXT NOT NULL,
            name_en TEXT NOT NULL,
            emoji TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE countries (
            id TEXT PRIMARY KEY,
            name_tr TEXT NOT NULL,
            name_en TEXT NOT NULL,
            continent_id TEXT NOT NULL,
            capital TEXT,
            flag TEXT,
            FOREIGN KEY (continent_id) REFERENCES continents (id)
          )
        ''');
        await db.execute('''
          CREATE TABLE provinces (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            country_id TEXT NOT NULL,
            is_capital INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (country_id) REFERENCES countries (id)
          )
        ''');
        await db.execute('CREATE INDEX idx_provinces_country ON provinces (country_id)');
        await db.execute('''
          CREATE TABLE cities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            seed_key TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            country_id TEXT NOT NULL,
            is_capital INTEGER NOT NULL DEFAULT 0,
            visited INTEGER NOT NULL DEFAULT 0,
            visited_at TEXT,
            province_id TEXT,
            FOREIGN KEY (country_id) REFERENCES countries (id),
            FOREIGN KEY (province_id) REFERENCES provinces (id)
          )
        ''');
        await db.execute('CREATE INDEX idx_cities_country ON cities (country_id)');
        await db.execute('CREATE INDEX idx_cities_province ON cities (province_id)');
        await db.execute('''
          CREATE TABLE meta (
            key TEXT PRIMARY KEY,
            value TEXT
          )
        ''');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute('''
            CREATE TABLE IF NOT EXISTS provinces (
              id TEXT PRIMARY KEY,
              name TEXT NOT NULL,
              country_id TEXT NOT NULL,
              is_capital INTEGER NOT NULL DEFAULT 0,
              FOREIGN KEY (country_id) REFERENCES countries (id)
            )
          ''');
          await db.execute('CREATE INDEX IF NOT EXISTS idx_provinces_country ON provinces (country_id)');

          final cityColumns = await db.rawQuery('PRAGMA table_info(cities)');
          final hasProvinceId = cityColumns.any((c) => c['name'] == 'province_id');
          if (!hasProvinceId) {
            await db.execute('ALTER TABLE cities ADD COLUMN province_id TEXT');
            await db.execute('CREATE INDEX IF NOT EXISTS idx_cities_province ON cities (province_id)');
          }
        }
      },
    );

    await _seedIfNeeded(db);
    return db;
  }

  Future<void> _seedIfNeeded(Database db) async {
    final existing = await db.query(
      'meta',
      where: 'key = ?',
      whereArgs: ['seed_data_version'],
    );
    final currentVersion = existing.isNotEmpty ? existing.first['value'] as String? : null;

    if (currentVersion == _seedDataVersion) {
      return; // Bu veri sürümü zaten yüklenmiş.
    }

    final continentsJson = await rootBundle.loadString('assets/data/continents.json');
    final countriesJson = await rootBundle.loadString('assets/data/countries.json');
    final provincesJson = await rootBundle.loadString('assets/data/provinces.json');
    final citiesJson = await rootBundle.loadString('assets/data/cities.json');

    final continents = jsonDecode(continentsJson) as List<dynamic>;
    final countries = jsonDecode(countriesJson) as List<dynamic>;
    final provinces = jsonDecode(provincesJson) as List<dynamic>;
    final cities = jsonDecode(citiesJson) as List<dynamic>;

    await db.transaction((txn) async {
      // Türkiye'nin şehir listesi bu uygulamanın geliştirilmesi sırasında
      // birkaç kez şekil değiştirdi (81 il -> 81 il + 973 ilçe -> tekrar
      // yalnızca 81 il). seed_key kararlı olduğu için, artık yeni veri
      // setinde YER ALMAYAN eski TR satırlarını (ör. bir önceki ilçe
      // sürümünden kalan satırlar) burada tespit edip temizliyoruz; hâlâ
      // geçerli olan satırlara (ve kullanıcının "gezildi" işaretlerine)
      // dokunulmaz.
      final validTrSeedKeys = cities
          .where((c) => c['country_id'] == 'TR')
          .map((c) => c['key'] as String)
          .toSet();
      final existingTrRows = await txn.query(
        'cities',
        columns: ['id', 'seed_key'],
        where: 'country_id = ?',
        whereArgs: ['TR'],
      );
      final staleTrIds = existingTrRows
          .where((r) => !validTrSeedKeys.contains(r['seed_key'] as String))
          .map((r) => r['id'] as int)
          .toList();

      final batch = txn.batch();

      // `provinces` salt referans veridir (kendi "gezildi" durumu yok,
      // istatistikler `cities` üzerinden hesaplanır), bu yüzden her seed
      // geçişinde güvenle temizlenip yeniden yazılabilir.
      batch.delete('provinces');

      for (final c in continents) {
        batch.insert(
          'continents',
          {
            'id': c['id'],
            'name_tr': c['name_tr'],
            'name_en': c['name_en'],
            'emoji': c['emoji'],
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }

      for (final c in countries) {
        batch.insert(
          'countries',
          {
            'id': c['id'],
            'name_tr': c['name_tr'],
            'name_en': c['name_en'],
            'continent_id': c['continent_id'],
            'capital': c['capital'],
            'flag': c['flag'],
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }

      for (final p in provinces) {
        batch.insert(
          'provinces',
          {
            'id': p['id'],
            'name': p['name'],
            'country_id': p['country_id'],
            'is_capital': (p['is_capital'] as bool) ? 1 : 0,
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }

      // Şehirlerde ConflictAlgorithm.ignore kullanılır: seed_key zaten
      // varsa (kullanıcı daha önce bu şehri işaretlemiş olabilir) satır
      // DOKUNULMADAN bırakılır; sadece yeni eklenen şehirler eklenir.
      for (final c in cities) {
        batch.insert(
          'cities',
          {
            'seed_key': c['key'],
            'name': c['name'],
            'country_id': c['country_id'],
            'is_capital': (c['is_capital'] as bool) ? 1 : 0,
            'visited': 0,
            'province_id': c['province_id'] as String?,
          },
          conflictAlgorithm: ConflictAlgorithm.ignore,
        );
      }

      // Yukarıda hesaplanan, yeni veri setinde artık karşılığı olmayan eski
      // TR satırlarını temizle (bkz. üstteki not).
      for (final staleId in staleTrIds) {
        batch.delete('cities', where: 'id = ?', whereArgs: [staleId]);
      }

      batch.insert(
        'meta',
        {'key': 'seed_data_version', 'value': _seedDataVersion},
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

      await batch.commit(noResult: true);
    });
  }

  // ---------------------------------------------------------------------
  // Yazma işlemleri
  // ---------------------------------------------------------------------

  Future<void> setCityVisited(int cityId, bool visited) async {
    final db = await database;
    await db.update(
      'cities',
      {
        'visited': visited ? 1 : 0,
        'visited_at': visited ? DateTime.now().toIso8601String() : null,
      },
      where: 'id = ?',
      whereArgs: [cityId],
    );
  }

  /// Bir ülkenin tüm şehirlerini tek seferde işaretler/kaldırır.
  Future<void> setCountryAllVisited(String countryId, bool visited) async {
    final db = await database;
    await db.update(
      'cities',
      {
        'visited': visited ? 1 : 0,
        'visited_at': visited ? DateTime.now().toIso8601String() : null,
      },
      where: 'country_id = ?',
      whereArgs: [countryId],
    );
  }

  /// Bir ilin tüm ilçelerini tek seferde işaretler/kaldırır.
  Future<void> setProvinceAllVisited(String provinceId, bool visited) async {
    final db = await database;
    await db.update(
      'cities',
      {
        'visited': visited ? 1 : 0,
        'visited_at': visited ? DateTime.now().toIso8601String() : null,
      },
      where: 'province_id = ?',
      whereArgs: [provinceId],
    );
  }

  Future<void> resetAllVisited() async {
    final db = await database;
    await db.update('cities', {'visited': 0, 'visited_at': null});
  }

  // ---------------------------------------------------------------------
  // Okuma yardımcıları (ham map listeleri; servis katmanında modele çevrilir)
  // ---------------------------------------------------------------------

  Future<List<Map<String, dynamic>>> getContinents() async {
    final db = await database;
    return db.query('continents', orderBy: 'name_tr ASC');
  }

  Future<List<Map<String, dynamic>>> getCountries({String? continentId}) async {
    final db = await database;
    if (continentId != null) {
      return db.query(
        'countries',
        where: 'continent_id = ?',
        whereArgs: [continentId],
        orderBy: 'name_tr ASC',
      );
    }
    return db.query('countries', orderBy: 'name_tr ASC');
  }

  Future<Map<String, dynamic>?> getCountry(String countryId) async {
    final db = await database;
    final rows = await db.query(
      'countries',
      where: 'id = ?',
      whereArgs: [countryId],
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first;
  }

  /// Bir ülkenin illeri (varsa). Boş liste dönerse o ülke hâlâ eski
  /// davranışla (ülke -> düz şehir listesi) gösterilir.
  Future<List<Map<String, dynamic>>> getProvinces({required String countryId}) async {
    final db = await database;
    return db.query(
      'provinces',
      where: 'country_id = ?',
      whereArgs: [countryId],
      orderBy: 'is_capital DESC, name ASC',
    );
  }

  Future<Map<String, dynamic>?> getProvince(String provinceId) async {
    final db = await database;
    final rows = await db.query(
      'provinces',
      where: 'id = ?',
      whereArgs: [provinceId],
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first;
  }

  Future<List<Map<String, dynamic>>> getDistricts({
    required String provinceId,
    String? searchQuery,
  }) async {
    final db = await database;
    if (searchQuery != null && searchQuery.trim().isNotEmpty) {
      return db.query(
        'cities',
        where: 'province_id = ? AND name LIKE ?',
        whereArgs: [provinceId, '%${searchQuery.trim()}%'],
        orderBy: 'is_capital DESC, name ASC',
      );
    }
    return db.query(
      'cities',
      where: 'province_id = ?',
      whereArgs: [provinceId],
      orderBy: 'is_capital DESC, name ASC',
    );
  }

  /// Bir ülkedeki her il için toplam/gezilen ilçe sayısı.
  Future<List<Map<String, dynamic>>> getProvinceTotals({required String countryId}) async {
    final db = await database;
    return db.rawQuery('''
      SELECT
        p.id AS province_id,
        COUNT(ci.id) AS total_cities,
        SUM(ci.visited) AS visited_cities
      FROM provinces p
      LEFT JOIN cities ci ON ci.province_id = p.id
      WHERE p.country_id = ?
      GROUP BY p.id
    ''', [countryId]);
  }

  Future<List<Map<String, dynamic>>> getCities({
    required String countryId,
    String? searchQuery,
  }) async {
    final db = await database;
    if (searchQuery != null && searchQuery.trim().isNotEmpty) {
      return db.query(
        'cities',
        where: 'country_id = ? AND name LIKE ?',
        whereArgs: [countryId, '%${searchQuery.trim()}%'],
        orderBy: 'is_capital DESC, name ASC',
      );
    }
    return db.query(
      'cities',
      where: 'country_id = ?',
      whereArgs: [countryId],
      orderBy: 'is_capital DESC, name ASC',
    );
  }

  /// Dünya genelinde toplam / gezilen şehir sayısı.
  Future<(int total, int visited)> getWorldTotals() async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT COUNT(*) as total, SUM(visited) as visited FROM cities',
    );
    final row = result.first;
    final total = (row['total'] as int?) ?? 0;
    final visited = (row['visited'] as int?) ?? 0;
    return (total, visited);
  }

  /// Kıta bazında toplam/gezilen şehir sayısı ve ülke sayısı.
  Future<List<Map<String, dynamic>>> getContinentTotals() async {
    final db = await database;
    return db.rawQuery('''
      SELECT
        co.continent_id AS continent_id,
        COUNT(ci.id) AS total_cities,
        SUM(ci.visited) AS visited_cities,
        COUNT(DISTINCT co.id) AS total_countries,
        COUNT(DISTINCT CASE WHEN ci.visited = 1 THEN co.id END) AS visited_countries
      FROM countries co
      LEFT JOIN cities ci ON ci.country_id = co.id
      GROUP BY co.continent_id
    ''');
  }

  /// Belirli bir kıtadaki her ülke için toplam/gezilen şehir sayısı.
  Future<List<Map<String, dynamic>>> getCountryTotals({String? continentId}) async {
    final db = await database;
    if (continentId != null) {
      return db.rawQuery('''
        SELECT
          co.id AS country_id,
          COUNT(ci.id) AS total_cities,
          SUM(ci.visited) AS visited_cities
        FROM countries co
        LEFT JOIN cities ci ON ci.country_id = co.id
        WHERE co.continent_id = ?
        GROUP BY co.id
      ''', [continentId]);
    }
    return db.rawQuery('''
      SELECT
        co.id AS country_id,
        COUNT(ci.id) AS total_cities,
        SUM(ci.visited) AS visited_cities
      FROM countries co
      LEFT JOIN cities ci ON ci.country_id = co.id
      GROUP BY co.id
    ''');
  }

  Future<void> close() async {
    final db = _db;
    if (db != null) {
      await db.close();
      _db = null;
    }
  }
}
