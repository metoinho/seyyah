import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'config/backend_config.dart';
import 'providers/travel_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // BackendConfig içindeki Firebase anahtarları henüz doldurulmadıysa
  // (bkz. README "Gerçek e-posta doğrulaması" bölümü) başlatmayı atla —
  // giriş ekranı bunu algılayıp kullanıcıya açıklayıcı bir mesaj gösterir,
  // uygulamanın geri kalanı (kıta/ülke/şehir listeleri) bundan ETKİLENMEZ.
  if (BackendConfig.isFirebaseConfigured) {
    await Firebase.initializeApp(options: BackendConfig.firebaseOptions);
  }

  runApp(
    ChangeNotifierProvider(
      create: (_) => TravelProvider(),
      child: const SeyyahApp(),
    ),
  );
}
