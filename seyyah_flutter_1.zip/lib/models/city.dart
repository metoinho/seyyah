class City {
  final int? id; // yerel DB satır kimliği (autoincrement)
  final String seedKey; // JSON'daki kararlı anahtar, ör. "TR_ISTANBUL"
  final String name;
  final String countryId;
  final bool isCapital;
  final bool visited;
  final String? provinceId; // yalnızca Türkiye ilçelerinde dolu (il/ilçe hiyerarşisi)

  const City({
    this.id,
    required this.seedKey,
    required this.name,
    required this.countryId,
    required this.isCapital,
    this.visited = false,
    this.provinceId,
  });

  factory City.fromSeed(Map<String, dynamic> map) {
    return City(
      seedKey: map['key'] as String,
      name: map['name'] as String,
      countryId: map['country_id'] as String,
      isCapital: (map['is_capital'] as bool?) ?? false,
      provinceId: map['province_id'] as String?,
    );
  }

  factory City.fromDb(Map<String, dynamic> map) {
    return City(
      id: map['id'] as int?,
      seedKey: map['seed_key'] as String,
      name: map['name'] as String,
      countryId: map['country_id'] as String,
      isCapital: (map['is_capital'] as int? ?? 0) == 1,
      visited: (map['visited'] as int? ?? 0) == 1,
      provinceId: map['province_id'] as String?,
    );
  }

  City copyWith({bool? visited}) {
    return City(
      id: id,
      seedKey: seedKey,
      name: name,
      countryId: countryId,
      isCapital: isCapital,
      visited: visited ?? this.visited,
      provinceId: provinceId,
    );
  }

  Map<String, dynamic> toDbMap() => {
        if (id != null) 'id': id,
        'seed_key': seedKey,
        'name': name,
        'country_id': countryId,
        'is_capital': isCapital ? 1 : 0,
        'visited': visited ? 1 : 0,
        'province_id': provinceId,
      };
}
