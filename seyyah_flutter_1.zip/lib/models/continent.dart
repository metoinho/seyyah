class Continent {
  final String id; // "AF", "AS", "EU", "NA", "SA", "OC", "AN"
  final String nameTr;
  final String nameEn;
  final String emoji;

  const Continent({
    required this.id,
    required this.nameTr,
    required this.nameEn,
    required this.emoji,
  });

  factory Continent.fromMap(Map<String, dynamic> map) {
    return Continent(
      id: map['id'] as String,
      nameTr: map['name_tr'] as String,
      nameEn: map['name_en'] as String,
      emoji: map['emoji'] as String? ?? '🌍',
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'name_tr': nameTr,
        'name_en': nameEn,
        'emoji': emoji,
      };
}

/// Bir kıta için hesaplanmış ziyaret istatistikleri.
class ContinentStats {
  final Continent continent;
  final int totalCities;
  final int visitedCities;
  final int totalCountries;
  final int visitedCountries; // en az 1 şehri işaretlenmiş ülke sayısı

  const ContinentStats({
    required this.continent,
    required this.totalCities,
    required this.visitedCities,
    required this.totalCountries,
    required this.visitedCountries,
  });

  double get ratio => totalCities == 0 ? 0 : visitedCities / totalCities;
  double get percent => ratio * 100;
}
