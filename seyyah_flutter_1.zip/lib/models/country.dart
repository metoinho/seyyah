class Country {
  final String id; // ISO 3166-1 alpha-2 (ör. "TR")
  final String nameTr;
  final String nameEn;
  final String continentId;
  final String capital;
  final String flagEmoji;
  final double? lat;
  final double? lng;

  const Country({
    required this.id,
    required this.nameTr,
    required this.nameEn,
    required this.continentId,
    required this.capital,
    required this.flagEmoji,
    this.lat,
    this.lng,
  });

  factory Country.fromMap(Map<String, dynamic> map) {
    return Country(
      id: map['id'] as String,
      nameTr: map['name_tr'] as String,
      nameEn: map['name_en'] as String,
      continentId: map['continent_id'] as String,
      capital: map['capital'] as String? ?? '',
      flagEmoji: map['flag'] as String? ?? '',
      lat: (map['lat'] as num?)?.toDouble(),
      lng: (map['lng'] as num?)?.toDouble(),
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'name_tr': nameTr,
        'name_en': nameEn,
        'continent_id': continentId,
        'capital': capital,
        'flag': flagEmoji,
        'lat': lat,
        'lng': lng,
      };
}

/// Bir ülke için hesaplanmış ziyaret istatistikleri.
class CountryStats {
  final Country country;
  final int totalCities;
  final int visitedCities;

  const CountryStats({
    required this.country,
    required this.totalCities,
    required this.visitedCities,
  });

  double get ratio => totalCities == 0 ? 0 : visitedCities / totalCities;
  double get percent => ratio * 100;
  bool get isFullyVisited => totalCities > 0 && visitedCities == totalCities;
  bool get isPartiallyVisited => visitedCities > 0 && !isFullyVisited;
}
