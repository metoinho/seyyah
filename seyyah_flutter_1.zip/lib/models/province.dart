/// Bir ülkenin il/eyalet gibi ara katman birimi.
///
/// Şu an yalnızca Türkiye için kullanılır (81 il), ancak veri-tabanlı
/// tutulur (`country_id` alanı üzerinden) ki ileride başka ülkelere de
/// genişletilebilsin.
class Province {
  final String id; // ör. "TR_ANKARA"
  final String name;
  final String countryId;
  final bool isCapital;

  const Province({
    required this.id,
    required this.name,
    required this.countryId,
    required this.isCapital,
  });

  factory Province.fromMap(Map<String, dynamic> map) {
    return Province(
      id: map['id'] as String,
      name: map['name'] as String,
      countryId: map['country_id'] as String,
      isCapital: (map['is_capital'] is bool)
          ? map['is_capital'] as bool
          : (map['is_capital'] as int? ?? 0) == 1,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'country_id': countryId,
        'is_capital': isCapital ? 1 : 0,
      };
}

/// Bir il için hesaplanmış ziyaret istatistikleri (ilçeler üzerinden).
class ProvinceStats {
  final Province province;
  final int totalDistricts;
  final int visitedDistricts;

  const ProvinceStats({
    required this.province,
    required this.totalDistricts,
    required this.visitedDistricts,
  });

  double get ratio => totalDistricts == 0 ? 0 : visitedDistricts / totalDistricts;
  double get percent => ratio * 100;
  bool get isFullyVisited => totalDistricts > 0 && visitedDistricts == totalDistricts;
  bool get isPartiallyVisited => visitedDistricts > 0 && !isFullyVisited;
}
