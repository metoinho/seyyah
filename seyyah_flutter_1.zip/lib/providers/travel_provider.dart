import 'package:flutter/foundation.dart';

import '../models/city.dart';
import '../models/continent.dart';
import '../models/country.dart';
import '../models/province.dart';
import '../services/auth_service.dart';
import '../services/stats_service.dart';

/// Uygulama genelinde tek bir yerden okunan, ziyaret durumu her
/// değiştiğinde tüm ekranları güncelleyen paylaşılan durum (state).
class TravelProvider extends ChangeNotifier {
  final StatsService _stats = StatsService();

  bool _loading = true;
  bool get loading => _loading;

  int worldTotal = 0;
  int worldVisited = 0;
  double get worldPercent => worldTotal == 0 ? 0 : (worldVisited / worldTotal) * 100;

  List<ContinentStats> continentStats = [];

  // Giriş yapmış kişinin adı/e-postası (bkz. AuthScreen, AuthService).
  String? userName;
  String? userEmail;

  TravelProvider() {
    _refreshAll();
    _loadSession();
  }

  Future<void> _loadSession() async {
    final session = await AuthService.instance.getSession();
    userName = session?.name;
    userEmail = session?.email;
    notifyListeners();
  }

  Future<void> signOut() async {
    await AuthService.instance.clearSession();
    userName = null;
    userEmail = null;
    notifyListeners();
  }

  Future<void> _refreshAll() async {
    _loading = true;
    notifyListeners();

    final world = await _stats.getWorldStats();
    final continents = await _stats.getContinentStatsList();

    worldTotal = world.total;
    worldVisited = world.visited;
    continentStats = continents;

    _loading = false;
    notifyListeners();
  }

  Future<void> refresh() => _refreshAll();

  Future<List<CountryStats>> countryStatsFor(String continentId) {
    return _stats.getCountryStatsList(continentId: continentId);
  }

  Future<CountryStats?> countryStats(String countryId) {
    return _stats.getCountryStats(countryId);
  }

  /// Harita ekranı için dünyadaki tüm ülkelerin istatistikleri.
  Future<List<CountryStats>> allCountryStats() {
    return _stats.getCountryStatsList();
  }

  Future<List<City>> citiesFor(String countryId, {String? search}) {
    return _stats.getCities(countryId, search: search);
  }

  /// Bir ülkenin illeri (varsa). Boşsa o ülke eski davranışla (düz şehir
  /// listesi) gösterilir — Türkiye dışındaki tüm ülkelerde boş döner.
  Future<List<Province>> provincesFor(String countryId) {
    return _stats.getProvinces(countryId);
  }

  Future<List<ProvinceStats>> provinceStatsFor(String countryId) {
    return _stats.getProvinceStatsList(countryId);
  }

  Future<ProvinceStats?> provinceStats(String provinceId) {
    return _stats.getProvinceStats(provinceId);
  }

  Future<List<City>> districtsFor(String provinceId, {String? search}) {
    return _stats.getDistricts(provinceId, search: search);
  }

  Future<void> toggleCityVisited(int cityId, bool visited) async {
    await _stats.setCityVisited(cityId, visited);
    await _refreshAll();
  }

  Future<void> markCountry(String countryId, bool visited) async {
    await _stats.setCountryAllVisited(countryId, visited);
    await _refreshAll();
  }

  Future<void> markProvince(String provinceId, bool visited) async {
    await _stats.setProvinceAllVisited(provinceId, visited);
    await _refreshAll();
  }

  Future<void> resetAll() async {
    await _stats.resetAllVisited();
    await _refreshAll();
  }
}
