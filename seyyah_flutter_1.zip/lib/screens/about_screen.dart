import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../theme/app_theme.dart';
import '../utils/constants.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hakkında')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          // Logodaki bavul ikonu kaldırıldı — yalnızca "SEYYAH" yazısı
          // gösteriliyor.
          Center(
            child: Text(
              AppConstants.appName,
              style: GoogleFonts.abrilFatface(
                fontSize: 26,
                color: AppColors.onBlue,
                letterSpacing: 3,
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Center(
            child: Text(
              AppConstants.appTagline,
              style: TextStyle(color: AppColors.onBlueMuted),
            ),
          ),
          const SizedBox(height: 28),
          // Metin gövdesi, mavi sayfa zemini üzerinde okunaklı kalması için
          // beyaz bir kart içine alınıyor (bkz. web sürümündeki hakkında
          // penceresi).
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppColors.divider),
            ),
            child: const Column(
              children: [
                _Paragraph(
                  'SEYYAH, dünyayı; kıtalar, ülkeler ve şehirler halinde keşfetmenize '
                  've gezdiğiniz yerleri işaretleyerek dünyanın, bir kıtanın veya bir '
                  'ülkenin yüzde kaçını gördüğünüzü anında hesaplamanıza yardımcı olur.',
                ),
                SizedBox(height: 16),
                _Paragraph(
                  'Yüzde hesabı, o birimdeki toplam şehir sayısına göre yapılır: '
                  'örneğin bir ülkede 20 şehir tanımlıysa ve bunlardan 5\'i '
                  'işaretlenmişse, o ülke "%25,0 gezildi" olarak gösterilir. Kıta ve '
                  'dünya yüzdeleri de aynı mantıkla, alttaki tüm şehirlerin toplamı '
                  'üzerinden hesaplanır.',
                ),
                SizedBox(height: 16),
                _Paragraph(
                  'Tüm verileriniz yalnızca cihazınızda saklanır.',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Paragraph extends StatelessWidget {
  final String text;
  const _Paragraph(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      textAlign: TextAlign.center,
      style: const TextStyle(fontSize: 14, height: 1.5, color: AppColors.ink),
    );
  }
}
