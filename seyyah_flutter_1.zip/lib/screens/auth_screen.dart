import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../config/backend_config.dart';
import '../services/auth_service.dart';
import '../services/email_verification_service.dart';
import '../utils/constants.dart';
import 'home_screen.dart';

/// Giriş / kayıt ekranı: tamamen kırmızı zemin üzerinde SEYYAH logosu,
/// ardından isim + e-posta alınıp e-postaya GERÇEK bir 6 haneli doğrulama
/// kodu gönderilir (bkz. EmailVerificationService). Kod doğrulanınca
/// oturum cihazda saklanır.
class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();

  int _step = 1; // 1: isim + e-posta, 2: kod doğrulama
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _codeCtrl.dispose();
    super.dispose();
  }

  bool _isValidEmail(String v) {
    return RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(v);
  }

  Future<void> _submitStep1() async {
    final name = _nameCtrl.text.trim();
    final email = _emailCtrl.text.trim().toLowerCase();
    setState(() => _error = null);
    if (name.isEmpty) {
      setState(() => _error = 'Lütfen adını gir.');
      return;
    }
    if (!_isValidEmail(email)) {
      setState(() => _error = 'Geçerli bir e-posta adresi gir.');
      return;
    }
    if (!BackendConfig.isFirebaseConfigured || !BackendConfig.isEmailJsConfigured) {
      setState(() {
        _error = 'Geliştirici ayarları eksik: lib/config/backend_config.dart '
            'içindeki Firebase/EmailJS anahtarları henüz doldurulmamış '
            '(bkz. README).';
      });
      return;
    }
    setState(() => _loading = true);
    try {
      await EmailVerificationService.instance.requestCode(name: name, email: email);
      if (!mounted) return;
      setState(() {
        _codeCtrl.clear();
        _step = 2;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Kod gönderilemedi. İnternet bağlantını ve geliştirici '
            'ayarlarını kontrol et.';
        _loading = false;
      });
    }
  }

  Future<void> _submitStep2() async {
    setState(() {
      _error = null;
      _loading = true;
    });
    final name = _nameCtrl.text.trim();
    final email = _emailCtrl.text.trim().toLowerCase();
    try {
      await EmailVerificationService.instance.verifyCode(
        name: name,
        email: email,
        code: _codeCtrl.text.trim(),
      );
      await AuthService.instance.saveSession(AuthSession(name: name, email: email));
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    } on WrongCodeException {
      if (!mounted) return;
      setState(() {
        _error = 'Kod yanlış, tekrar dene.';
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Doğrulama başarısız oldu. Tekrar dene.';
        _loading = false;
      });
    }
  }

  Future<void> _resendCode() async {
    setState(() {
      _error = null;
      _loading = true;
    });
    try {
      await EmailVerificationService.instance.requestCode(
        name: _nameCtrl.text.trim(),
        email: _emailCtrl.text.trim().toLowerCase(),
      );
      if (!mounted) return;
      setState(() {
        _error = 'Yeni kod gönderildi.';
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Kod gönderilemedi, tekrar dene.';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFE10E1A), Color(0xFFA3040F)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
            child: Column(
              children: [
                // Logodaki bavul ikonu kaldırıldı — yalnızca "SEYYAH"
                // yazısı gösteriliyor.
                const SizedBox(height: 40),
                Text(
                  'SEYYAH',
                  style: GoogleFonts.abrilFatface(
                    color: Colors.white,
                    fontSize: 26,
                    letterSpacing: 3,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  AppConstants.appTagline,
                  style: const TextStyle(color: Colors.white70, fontSize: 13.5),
                ),
                const SizedBox(height: 28),
                if (_step == 1) _buildStep1() else _buildStep2(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStep1() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (_error != null) _errorBanner(_error!),
        _label('Adın'),
        _field(controller: _nameCtrl, hint: 'Adın', keyboardType: TextInputType.name),
        const SizedBox(height: 12),
        _label('E-posta'),
        _field(controller: _emailCtrl, hint: 'E-posta adresin', keyboardType: TextInputType.emailAddress),
        const SizedBox(height: 18),
        _primaryButton('Kod Gönder', _loading ? null : _submitStep1, loading: _loading),
      ],
    );
  }

  Widget _buildStep2() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          'Kodu gir',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16),
        ),
        const SizedBox(height: 6),
        Text(
          '${_emailCtrl.text.trim()} adresine gönderdiğimiz 6 haneli kodu gir.',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white70, fontSize: 13, height: 1.4),
        ),
        const SizedBox(height: 18),
        if (_error != null) _errorBanner(_error!),
        _label('Doğrulama kodu'),
        _field(
          controller: _codeCtrl,
          hint: '••••••',
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(6)],
          textAlign: TextAlign.center,
          letterSpacing: 8,
        ),
        const SizedBox(height: 18),
        _primaryButton('Doğrula', _loading ? null : _submitStep2, loading: _loading),
        const SizedBox(height: 14),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            TextButton(
              onPressed: _loading ? null : () => setState(() { _step = 1; _error = null; }),
              child: const Text('Geri', style: TextStyle(color: Colors.white70)),
            ),
            TextButton(
              onPressed: _loading ? null : _resendCode,
              child: const Text('Kodu tekrar gönder', style: TextStyle(color: Colors.white70)),
            ),
          ],
        ),
      ],
    );
  }

  Widget _label(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 6, left: 2),
        child: Text(
          text.toUpperCase(),
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 11.5,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.5,
          ),
        ),
      );

  Widget _field({
    required TextEditingController controller,
    required String hint,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    TextAlign textAlign = TextAlign.start,
    double letterSpacing = 0,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      textAlign: textAlign,
      style: TextStyle(color: Colors.white, fontSize: 15, letterSpacing: letterSpacing),
      cursorColor: Colors.white,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white54),
        filled: true,
        fillColor: Colors.white.withOpacity(0.14),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.4), width: 1.5),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.4), width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.white, width: 1.5),
        ),
      ),
    );
  }

  Widget _primaryButton(String text, VoidCallback? onPressed, {bool loading = false}) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFFA3040F),
        padding: const EdgeInsets.symmetric(vertical: 15),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
      ),
      child: loading
          ? const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2.5, color: Color(0xFFA3040F)),
            )
          : Text(text),
    );
  }

  Widget _errorBanner(String text) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: const TextStyle(color: Color(0xFFA3040F), fontWeight: FontWeight.w700, fontSize: 12.5),
      ),
    );
  }
}
