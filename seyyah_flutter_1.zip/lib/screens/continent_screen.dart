import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/continent.dart';
import '../models/country.dart';
import '../providers/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/format.dart';
import '../widgets/search_field.dart';
import '../widgets/stat_card.dart';
import 'country_screen.dart';

class ContinentScreen extends StatefulWidget {
  final Continent continent;

  const ContinentScreen({super.key, required this.continent});

  @override
  State<ContinentScreen> createState() => _ContinentScreenState();
}

class _ContinentScreenState extends State<ContinentScreen> {
  List<CountryStats> _all = [];
  String _query = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final provider = context.read<TravelProvider>();
    final stats = await provider.countryStatsFor(widget.continent.id);
    if (!mounted) return;
    setState(() {
      _all = stats;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _query.trim().isEmpty
        ? _all
        : _all
            .where((c) =>
                c.country.nameTr.toLowerCase().contains(_query.toLowerCase()) ||
                c.country.nameEn.toLowerCase().contains(_query.toLowerCase()))
            .toList();

    final totalCities = _all.fold<int>(0, (sum, c) => sum + c.totalCities);
    final visitedCities = _all.fold<int>(0, (sum, c) => sum + c.visitedCities);
    final percent = totalCities == 0 ? 0.0 : (visitedCities / totalCities) * 100;

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.continent.emoji}  ${widget.continent.nameTr}'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                children: [
                  StatHeroCard(
                    title: '${widget.continent.nameTr} · %${fmtPercent(percent)}',
                    subtitle: '$visitedCities / $totalCities şehir gezildi · ${_all.length} ülke',
                    percent: percent,
                  ),
                  const SizedBox(height: 20),
                  SearchField(
                    hintText: 'Ülke ara...',
                    onChanged: (v) => setState(() => _query = v),
                  ),
                  const SizedBox(height: 16),
                  if (filtered.isEmpty)
                    const Padding(
                      padding: EdgeInsets.only(top: 40),
                      child: Center(
                        child: Text(
                          'Sonuç bulunamadı',
                          style: TextStyle(color: AppColors.onBlueMuted),
                        ),
                      ),
                    )
                  else
                    ...filtered.map((cs) {
                      return StatListTile(
                        leadingEmoji: cs.country.flagEmoji,
                        title: cs.country.nameTr,
                        subtitle: '${cs.visitedCities}/${cs.totalCities} şehir · ${cs.country.capital}',
                        percent: cs.percent,
                        onTap: () async {
                          await Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => CountryScreen(country: cs.country),
                            ),
                          );
                          _load();
                        },
                      );
                    }),
                ],
              ),
            ),
    );
  }
}
