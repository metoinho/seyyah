import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/city.dart';
import '../models/country.dart';
import '../models/province.dart';
import '../providers/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/format.dart';
import '../widgets/search_field.dart';
import '../widgets/stat_card.dart';
import 'province_screen.dart';

class CountryScreen extends StatefulWidget {
  final Country country;

  const CountryScreen({super.key, required this.country});

  @override
  State<CountryScreen> createState() => _CountryScreenState();
}

class _CountryScreenState extends State<CountryScreen> {
  // Türkiye gibi il/ilçe hiyerarşisi olan ülkelerde `_provinces` doludur ve
  // ekran, düz şehir listesi yerine il listesini gösterir. Diğer tüm
  // ülkelerde `_provinces` boş kalır ve eski davranış (düz şehir listesi)
  // aynen sürer.
  List<ProvinceStats> _provinces = [];
  List<City> _cities = [];
  bool _loading = true;
  bool _hasProvinces = false;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final provider = context.read<TravelProvider>();
    final provinces = await provider.provincesFor(widget.country.id);
    if (provinces.isNotEmpty) {
      final stats = await provider.provinceStatsFor(widget.country.id);
      if (!mounted) return;
      setState(() {
        _hasProvinces = true;
        _provinces = stats;
        _loading = false;
      });
      return;
    }

    final cities = await provider.citiesFor(widget.country.id, search: _query);
    if (!mounted) return;
    setState(() {
      _hasProvinces = false;
      _cities = cities;
      _loading = false;
    });
  }

  int get _visitedCount => _cities.where((c) => c.visited).length;

  double get _percent {
    if (_hasProvinces) {
      final total = _provinces.fold<int>(0, (sum, p) => sum + p.totalDistricts);
      final visited = _provinces.fold<int>(0, (sum, p) => sum + p.visitedDistricts);
      return total == 0 ? 0 : (visited / total) * 100;
    }
    if (_cities.isEmpty) return 0;
    return (_visitedCount / _cities.length) * 100;
  }

  Future<void> _toggle(City city, bool value) async {
    final provider = context.read<TravelProvider>();
    setState(() {
      final idx = _cities.indexWhere((c) => c.id == city.id);
      if (idx != -1) _cities[idx] = city.copyWith(visited: value);
    });
    await provider.toggleCityVisited(city.id!, value);
  }

  Future<void> _markAll(bool value) async {
    final provider = context.read<TravelProvider>();
    await provider.markCountry(widget.country.id, value);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final totalUnits = _hasProvinces
        ? _provinces.fold<int>(0, (sum, p) => sum + p.totalDistricts)
        : _cities.length;
    final visitedUnits = _hasProvinces
        ? _provinces.fold<int>(0, (sum, p) => sum + p.visitedDistricts)
        : _visitedCount;

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.country.flagEmoji}  ${widget.country.nameTr}'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'all') _markAll(true);
              if (v == 'none') _markAll(false);
            },
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'all',
                child: Text(_hasProvinces ? 'Tüm ilçeleri işaretle' : 'Tüm şehirleri işaretle'),
              ),
              const PopupMenuItem(value: 'none', child: Text('Tüm işaretleri kaldır')),
            ],
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                  child: Column(
                    children: [
                      StatHeroCard(
                        title:
                            '${widget.country.nameTr} · %${fmtPercent(_percent)}',
                        subtitle: _hasProvinces
                            ? '$visitedUnits / $totalUnits ilçe gezildi · ${_provinces.length} il'
                            : '$visitedUnits / $totalUnits şehir gezildi · Başkent: ${widget.country.capital}',
                        percent: _percent,
                      ),
                      const SizedBox(height: 16),
                      SearchField(
                        hintText: _hasProvinces ? 'İl ara...' : 'Şehir ara...',
                        onChanged: (v) {
                          _query = v;
                          if (_hasProvinces) {
                            setState(() {});
                          } else {
                            _load();
                          }
                        },
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: _hasProvinces ? _buildProvinceList() : _buildCityList(),
                ),
              ],
            ),
    );
  }

  Widget _buildProvinceList() {
    final filtered = _query.trim().isEmpty
        ? _provinces
        : _provinces
            .where((p) => p.province.name.toLowerCase().contains(_query.toLowerCase()))
            .toList();

    if (filtered.isEmpty) {
      // StatListTile satırları kendi beyaz kartını taşıdığı için normalde
      // panel gerekmez, ama boş durumda tek başına metin doğrudan mavi
      // zemin üzerinde kalır — bu yüzden okunaklı ton kullanılıyor.
      return const Center(
        child: Text('Sonuç bulunamadı', style: TextStyle(color: AppColors.onBlueMuted)),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      itemCount: filtered.length,
      itemBuilder: (context, index) {
        final ps = filtered[index];
        return StatListTile(
          leadingEmoji: '📍',
          title: ps.province.name,
          subtitle: '${ps.visitedDistricts}/${ps.totalDistricts} ilçe',
          percent: ps.percent,
          onTap: () async {
            await Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => ProvinceScreen(province: ps.province),
              ),
            );
            _load();
          },
        );
      },
    );
  }

  Widget _buildCityList() {
    // Düz onay kutusu listesi kendi kartını taşımıyor (StatListTile'ın
    // aksine), bu yüzden mavi sayfa zemini üzerinde okunaklı kalması için
    // tek, beyaz bir panel içine alınıyor (bkz. web sürümündeki .city-list).
    if (_cities.isEmpty) {
      return _whiteListPanel(
        const Center(
          child: Text('Sonuç bulunamadı', style: TextStyle(color: AppColors.inkMuted)),
        ),
      );
    }
    return _whiteListPanel(
      ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        itemCount: _cities.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) {
          final city = _cities[index];
          return CheckboxListTile(
            value: city.visited,
            onChanged: (v) => _toggle(city, v ?? false),
            controlAffinity: ListTileControlAffinity.leading,
            contentPadding: EdgeInsets.zero,
            title: Text(
              city.name,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            subtitle:
                city.isCapital ? const Text('Başkent', style: TextStyle(fontSize: 12)) : null,
            secondary: city.visited
                ? const Icon(Icons.check_circle, color: AppColors.seyyahRed)
                : const Icon(Icons.radio_button_unchecked, color: AppColors.unvisited),
          );
        },
      ),
    );
  }

  Widget _whiteListPanel(Widget child) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.divider),
      ),
      child: child,
    );
  }
}
