import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../providers/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import '../utils/format.dart';
import '../widgets/stat_card.dart';
import 'continent_screen.dart';
import 'map_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();

    return Scaffold(
      appBar: AppBar(
        // Logodaki bavul ikonu kaldırıldı — üst başlıkta artık yalnızca
        // "SEYYAH" yazısı gösteriliyor (önceki boyutunda, 58.5px). Büyük
        // yazı standart 56px'lik AppBar yüksekliğine tam sığmadığından
        // toolbarHeight biraz artırıldı.
        toolbarHeight: 74,
        title: Text(
          AppConstants.appName,
          style: GoogleFonts.abrilFatface(fontSize: 58.5, color: AppColors.onBlue),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.map_outlined),
            tooltip: 'Haritada gör',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const MapScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            tooltip: 'Ayarlar',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: provider.loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: provider.refresh,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                children: [
                  StatHeroCard(
                    title: (provider.userName != null && provider.userName!.isNotEmpty
                            ? '${provider.userName} '
                            : '') +
                        "Dünya'nın %${fmtPercent(provider.worldPercent)}'ini gezdin",
                    subtitle:
                        '${provider.worldVisited} / ${provider.worldTotal} şehir işaretlendi',
                    percent: provider.worldPercent,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const MapScreen()),
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Padding(
                    padding: EdgeInsets.only(left: 4, bottom: 10),
                    child: Text(
                      'Kıtalar',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: AppColors.onBlue,
                      ),
                    ),
                  ),
                  ...provider.continentStats.map((cs) {
                    return StatListTile(
                      leadingEmoji: cs.continent.emoji,
                      leadingImagePath:
                          'assets/images/continents/${cs.continent.id}.png',
                      title: cs.continent.nameTr,
                      subtitle:
                          '${cs.visitedCities}/${cs.totalCities} şehir · ${cs.visitedCountries}/${cs.totalCountries} ülke',
                      percent: cs.percent,
                      emphasized: true,
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => ContinentScreen(continent: cs.continent),
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
    );
  }
}
