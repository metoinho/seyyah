import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';

import '../models/country.dart';
import '../providers/travel_provider.dart';
import '../services/geo_boundaries_service.dart';
import '../theme/app_theme.dart';
import '../utils/format.dart';
import '../widgets/search_field.dart';
import 'country_screen.dart';

/// Dünya haritası ekranı.
///
/// Ülke sınırları, uygulama ilk kez bu ekrana girildiğinde cihaza indirilip
/// önbelleğe alınır (bkz. GeoBoundariesService). İnternet yoksa veya sınır
/// verisi hâlâ yükleniyorsa, altta bir liste/arama alanı ile ülkeye
/// SEYYAH'ın geri kalanındaki gibi doğrudan da ulaşılabilir — harita,
/// çekirdek işlevselliğin bir GÖRSEL EKİ'dir, tek yolu değildir.
class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final _geoService = GeoBoundariesService();
  final MapController _mapController = MapController();
  final _hitNotifier = ValueNotifier<LayerHitResult<String>?>(null);

  Map<String, List<List<LatLng>>> _polygonsByCountry = {};
  List<CountryStats> _countryStats = [];
  bool _loadingMap = true;
  bool _mapUnavailable = false;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final provider = context.read<TravelProvider>();
    final results = await Future.wait([
      _geoService.loadCountryPolygons(),
      provider.allCountryStats(),
    ]);

    if (!mounted) return;
    final polygons = results[0] as Map<String, List<List<LatLng>>>;
    setState(() {
      _polygonsByCountry = polygons;
      _countryStats = results[1] as List<CountryStats>;
      _mapUnavailable = polygons.isEmpty;
      _loadingMap = false;
    });
  }

  CountryStats? _statsFor(String countryId) {
    for (final cs in _countryStats) {
      if (cs.country.id == countryId) return cs;
    }
    return null;
  }

  void _openCountry(Country country) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => CountryScreen(country: country)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filteredStats = _query.trim().isEmpty
        ? const <CountryStats>[]
        : _countryStats
            .where((c) => c.country.nameTr.toLowerCase().contains(_query.toLowerCase()))
            .take(8)
            .toList();

    final polygons = <Polygon<String>>[];
    for (final entry in _polygonsByCountry.entries) {
      final stats = _statsFor(entry.key);
      final color = stats == null
          ? AppColors.unvisited
          : AppColors.progressColor(stats.ratio);
      for (final ring in entry.value) {
        polygons.add(
          Polygon<String>(
            points: ring,
            color: color.withOpacity(0.85),
            borderColor: AppColors.white,
            borderStrokeWidth: 0.6,
            hitValue: entry.key,
          ),
        );
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Dünya Haritam')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: SearchField(
              hintText: 'Ülke ara ve doğrudan aç...',
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          if (filteredStats.isNotEmpty)
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              constraints: const BoxConstraints(maxHeight: 220),
              decoration: BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.divider),
              ),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: filteredStats.length,
                itemBuilder: (context, i) {
                  final cs = filteredStats[i];
                  return ListTile(
                    dense: true,
                    leading: Text(cs.country.flagEmoji, style: const TextStyle(fontSize: 20)),
                    title: Text(cs.country.nameTr),
                    trailing: Text(
                      '%${fmtPercent(cs.percent)}',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    onTap: () {
                      setState(() => _query = '');
                      _openCountry(cs.country);
                    },
                  );
                },
              ),
            ),
          const SizedBox(height: 8),
          Expanded(
            child: _loadingMap
                ? const Center(child: CircularProgressIndicator())
                : _mapUnavailable
                    ? _MapUnavailableNotice(onOpenList: () {
                        Navigator.of(context).pop();
                      })
                    : ClipRRect(
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                        child: Container(
                          color: AppColors.offWhite,
                          child: FlutterMap(
                            mapController: _mapController,
                            options: MapOptions(
                              initialCenter: const LatLng(20, 10),
                              initialZoom: 1.6,
                              minZoom: 1.0,
                              maxZoom: 6.0,
                              onTap: (tapPosition, point) {
                                final hit = _hitNotifier.value;
                                if (hit == null || hit.hitValues.isEmpty) return;
                                final countryId = hit.hitValues.first;
                                final stats = _statsFor(countryId);
                                if (stats != null) _openCountry(stats.country);
                              },
                            ),
                            children: [
                              PolygonLayer<String>(
                                polygons: polygons,
                                hitNotifier: _hitNotifier,
                              ),
                            ],
                          ),
                        ),
                      ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _hitNotifier.dispose();
    super.dispose();
  }
}

class _MapUnavailableNotice extends StatelessWidget {
  final VoidCallback onOpenList;

  const _MapUnavailableNotice({required this.onOpenList});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Center(
        // Mavi sayfa zemini üzerinde okunaklı kalması için tüm bildirim
        // beyaz bir kart içine alınıyor (bkz. AboutScreen'deki metin
        // paneli ile aynı desen).
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.divider),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.wifi_off_rounded, size: 48, color: AppColors.inkMuted),
              const SizedBox(height: 16),
              const Text(
                'Harita şu anda yüklenemedi',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              const Text(
                'Görsel dünya haritası, sınır verisini indirmek için internet gerektirir. '
                'Bu, SEYYAH\'ın diğer tüm özelliklerini (kıta/ülke/şehir listeleri, '
                'yüzde hesapları) ETKİLEMEZ — yukarıdaki arama kutusunu kullanabilir '
                'ya da ana ekrandan kıtalara göz atabilirsiniz.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.inkMuted, fontSize: 13),
              ),
              const SizedBox(height: 20),
              OutlinedButton(onPressed: onOpenList, child: const Text('Listeye dön')),
            ],
          ),
        ),
      ),
    );
  }
}
