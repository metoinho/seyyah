import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/city.dart';
import '../models/province.dart';
import '../providers/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/format.dart';
import '../widgets/search_field.dart';
import '../widgets/stat_card.dart';

/// Bir ilin ilçelerini gösteren ve gezildi olarak işaretlemeye izin veren
/// ekran. `CountryScreen`'in il/ilçe hiyerarşisi olan ülkeler (şu an
/// yalnızca Türkiye) için karşılığıdır.
class ProvinceScreen extends StatefulWidget {
  final Province province;

  const ProvinceScreen({super.key, required this.province});

  @override
  State<ProvinceScreen> createState() => _ProvinceScreenState();
}

class _ProvinceScreenState extends State<ProvinceScreen> {
  List<City> _districts = [];
  bool _loading = true;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final provider = context.read<TravelProvider>();
    final districts = await provider.districtsFor(widget.province.id, search: _query);
    if (!mounted) return;
    setState(() {
      _districts = districts;
      _loading = false;
    });
  }

  int get _visitedCount => _districts.where((c) => c.visited).length;

  double get _percent {
    if (_districts.isEmpty) return 0;
    return (_visitedCount / _districts.length) * 100;
  }

  Future<void> _toggle(City city, bool value) async {
    final provider = context.read<TravelProvider>();
    setState(() {
      final idx = _districts.indexWhere((c) => c.id == city.id);
      if (idx != -1) _districts[idx] = city.copyWith(visited: value);
    });
    await provider.toggleCityVisited(city.id!, value);
  }

  Future<void> _markAll(bool value) async {
    final provider = context.read<TravelProvider>();
    await provider.markProvince(widget.province.id, value);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.province.name),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'all') _markAll(true);
              if (v == 'none') _markAll(false);
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'all', child: Text('Tüm ilçeleri işaretle')),
              PopupMenuItem(value: 'none', child: Text('Tüm işaretleri kaldır')),
            ],
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                  child: Column(
                    children: [
                      StatHeroCard(
                        title:
                            '${widget.province.name} · %${fmtPercent(_percent)}',
                        subtitle: '$_visitedCount / ${_districts.length} ilçe gezildi',
                        percent: _percent,
                      ),
                      const SizedBox(height: 16),
                      SearchField(
                        hintText: 'İlçe ara...',
                        onChanged: (v) {
                          _query = v;
                          _load();
                        },
                      ),
                    ],
                  ),
                ),
                Expanded(
                  // Düz onay kutusu listesi kendi kartını taşımıyor, bu yüzden
                  // mavi sayfa zemini üzerinde okunaklı kalması için tek,
                  // beyaz bir panel içine alınıyor (bkz. CountryScreen).
                  child: Container(
                    margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.divider),
                    ),
                    child: _districts.isEmpty
                        ? const Center(
                            child: Text(
                              'Sonuç bulunamadı',
                              style: TextStyle(color: AppColors.inkMuted),
                            ),
                          )
                        : ListView.separated(
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            itemCount: _districts.length,
                            separatorBuilder: (_, __) => const Divider(height: 1),
                            itemBuilder: (context, index) {
                              final district = _districts[index];
                              return CheckboxListTile(
                                value: district.visited,
                                onChanged: (v) => _toggle(district, v ?? false),
                                controlAffinity: ListTileControlAffinity.leading,
                                contentPadding: EdgeInsets.zero,
                                title: Text(
                                  district.name,
                                  style: const TextStyle(fontWeight: FontWeight.w600),
                                ),
                                subtitle: district.isCapital
                                    ? const Text('Başkent', style: TextStyle(fontSize: 12))
                                    : null,
                                secondary: district.visited
                                    ? const Icon(Icons.check_circle, color: AppColors.seyyahRed)
                                    : const Icon(Icons.radio_button_unchecked,
                                        color: AppColors.unvisited),
                              );
                            },
                          ),
                  ),
                ),
              ],
            ),
    );
  }
}
