import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/travel_provider.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import 'about_screen.dart';
import 'auth_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _confirmSignOut(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Çıkış yap'),
        content: const Text('Hesabından çıkış yapmak istediğine emin misin?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Çıkış yap', style: TextStyle(color: AppColors.seyyahRedDark)),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      await context.read<TravelProvider>().signOut();
      if (context.mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const AuthScreen()),
          (route) => false,
        );
      }
    }
  }

  Future<void> _confirmReset(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Tüm işaretleri sıfırla'),
        content: const Text(
          'Gezdiğiniz olarak işaretlediğiniz TÜM şehirler kaldırılacak. '
          'Bu işlem geri alınamaz. Devam etmek istiyor musunuz?',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Sıfırla', style: TextStyle(color: AppColors.seyyahRedDark)),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      await context.read<TravelProvider>().resetAll();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tüm işaretler sıfırlandı.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TravelProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Ayarlar')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (provider.userName != null)
            _SectionCard(
              children: [
                ListTile(
                  leading: const CircleAvatar(
                    backgroundColor: AppColors.seyyahRedSurface,
                    child: Icon(Icons.person, color: AppColors.seyyahRed),
                  ),
                  title: Text(
                    provider.userName!,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: Text(provider.userEmail ?? ''),
                  trailing: TextButton(
                    onPressed: () => _confirmSignOut(context),
                    child: const Text('Çıkış yap'),
                  ),
                ),
              ],
            ),
          if (provider.userName != null) const SizedBox(height: 16),
          _SectionCard(
            children: [
              ListTile(
                leading: const Icon(Icons.info_outline),
                title: const Text('Hakkında'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const AboutScreen()),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _SectionCard(
            children: [
              ListTile(
                leading: const Icon(Icons.restart_alt, color: AppColors.seyyahRedDark),
                title: const Text(
                  'Tüm işaretleri sıfırla',
                  style: TextStyle(color: AppColors.seyyahRedDark, fontWeight: FontWeight.w700),
                ),
                onTap: () => _confirmReset(context),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const Center(
            child: Text(
              '${AppConstants.appName} · sürüm 1.0.0',
              style: TextStyle(color: AppColors.onBlueMuted, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final List<Widget> children;
  const _SectionCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      child: Column(children: children),
    );
  }
}
