import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/auth_service.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';
import 'auth_screen.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateAfterDelay();
  }

  Future<void> _navigateAfterDelay() async {
    final session = await AuthService.instance.getSession();
    await Future.delayed(const Duration(milliseconds: 1100));
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => session == null ? const AuthScreen() : const HomeScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Logodaki bavul ikonu kaldırıldı — yalnızca canlı metin
            // kullanılıyor, böylece "SEYYAH" yazısı her yerde aynı
            // (Abril Fatface) fontla tutarlı kalıyor.
            Text(
              AppConstants.appName,
              style: GoogleFonts.abrilFatface(fontSize: 44, color: AppColors.seyyahRed),
            ),
            const SizedBox(height: 10),
            const Text(
              AppConstants.appTagline,
              style: TextStyle(fontSize: 13, color: AppColors.inkMuted),
            ),
          ],
        ),
      ),
    );
  }
}
