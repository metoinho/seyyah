import 'package:shared_preferences/shared_preferences.dart';

/// Giriş yapmış kişinin oturum bilgisi (isim + e-posta).
class AuthSession {
  final String name;
  final String email;

  const AuthSession({required this.name, required this.email});
}

/// Basit, yerel (cihaz üzerinde) oturum yönetimi.
///
/// NOT: Şu anki sürüm bir DEMO'dur — doğrulama kodu gerçekten e-postaya
/// gönderilmez, ekranda gösterilir (bkz. AuthScreen). Gerçek bir e-posta
/// servisi (ör. Supabase, Firebase, SendGrid) bağlandığında, kodun
/// üretilip gönderildiği kısım bir sunucu tarafına taşınmalı; bu servis
/// sınıfının arayüzü (saveSession/getSession/clearSession) aynı kalabilir.
class AuthService {
  AuthService._();
  static final AuthService instance = AuthService._();

  static const _kName = 'seyyah_session_name';
  static const _kEmail = 'seyyah_session_email';

  Future<AuthSession?> getSession() async {
    final prefs = await SharedPreferences.getInstance();
    final name = prefs.getString(_kName);
    final email = prefs.getString(_kEmail);
    if (name == null || email == null) return null;
    return AuthSession(name: name, email: email);
  }

  Future<void> saveSession(AuthSession session) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kName, session.name);
    await prefs.setString(_kEmail, session.email);
  }

  Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kName);
    await prefs.remove(_kEmail);
  }
}
