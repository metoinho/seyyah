import 'dart:convert';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;

import '../config/backend_config.dart';

/// Kullanıcının e-postasına GERÇEK bir doğrulama kodu gönderip
/// doğrulayan servis (bkz. `BackendConfig` içindeki mimari açıklaması).
///
/// Güvenlik notu: Doğrulama kodu hiçbir zaman istemciye (uygulamaya) geri
/// OKUNMAZ — yalnızca kullanıcının girdiği kodun doğru olup olmadığı,
/// Firestore güvenlik kurallarının sunucu tarafında yaptığı bir
/// karşılaştırmayla anlaşılır (bkz. proje köküdeki `firestore.rules`).
/// Bu, bir banka uygulaması kadar sıkı değildir (ör. deneme sayısı sınırı
/// yoktur) ama kodun asla dışarıdan okunamaması açısından sağlam bir
/// temel sunar — bir seyahat uygulaması için yeterlidir.
class WrongCodeException implements Exception {}

class EmailVerificationService {
  EmailVerificationService._();
  static final EmailVerificationService instance =
      EmailVerificationService._();

  String _generateCode() {
    final rnd = Random.secure();
    return (100000 + rnd.nextInt(900000)).toString();
  }

  /// Yeni bir kod üretir, Firestore'a yazar ve EmailJS ile kullanıcının
  /// e-postasına gönderir. Hata durumunda açıklayıcı bir [Exception] fırlatır.
  Future<void> requestCode({required String name, required String email}) async {
    final code = _generateCode();

    await FirebaseFirestore.instance.collection('verifications').doc(email).set({
      'code': code,
      'name': name,
      'createdAt': FieldValue.serverTimestamp(),
    });

    final response = await http.post(
      Uri.parse('https://api.emailjs.com/api/v1.0/email/send'),
      headers: {'origin': 'http://localhost', 'Content-Type': 'application/json'},
      body: jsonEncode({
        'service_id': BackendConfig.emailJsServiceId,
        'template_id': BackendConfig.emailJsTemplateId,
        'user_id': BackendConfig.emailJsPublicKey,
        'template_params': {
          'to_email': email,
          'name': name,
          'code': code,
        },
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('E-posta gönderilemedi (${response.statusCode}): ${response.body}');
    }
  }

  /// Kullanıcının girdiği kodu doğrular. Doğruysa kişinin adını
  /// `users/{email}` altına kaydeder (cihazlar arası kişiselleştirme
  /// için). Kod yanlışsa [WrongCodeException] fırlatır.
  Future<void> verifyCode({
    required String name,
    required String email,
    required String code,
  }) async {
    try {
      await FirebaseFirestore.instance.collection('verified_attempts').add({
        'email': email,
        'code': code,
        'at': FieldValue.serverTimestamp(),
      });
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') {
        throw WrongCodeException();
      }
      rethrow;
    }

    await FirebaseFirestore.instance.collection('users').doc(email).set({
      'name': name,
      'lastLoginAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }
}
