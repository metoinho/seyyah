import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';

/// Dünya haritası ekranındaki ülke sınırlarını sağlayan servis.
///
/// ÖNEMLİ: Bu sınıf, ülke sınır verisini (GeoJSON) UYGULAMA ÇALIŞIRKEN,
/// kullanıcının kendi cihazından indirir ve cihaza önbelleğe alır — bu
/// veri SEYYAH'ın kendisiyle birlikte paketlenmez. Böylece uygulama boyutu
/// küçük kalır ve harita her zaman güncel, düşük çözünürlüklü (110m) genel
/// hatlarla gösterilir.
///
/// Veri kaynağı: Natural Earth "Admin 0 – Countries" (110m, kamu malı /
/// public domain) — https://www.naturalearthdata.com
/// Varsayılan URL, bu veri setinin yaygın olarak barındırıldığı bir CDN
/// adresidir. Kurumsal/okul ağlarında bu adres engelliyse
/// `NaturalEarthUrls` listesindeki alternatiflerden biriyle değiştirin
/// veya kendi sunucunuzda barındırın.
///
/// İnternet yoksa veya indirme başarısız olursa harita ekranı sessizce
/// devre dışı kalır; uygulamanın geri kalanı (liste tabanlı gezinme ve
/// yüzde hesapları) BUNDAN ETKİLENMEZ.
class GeoBoundariesService {
  static const List<String> naturalEarthUrls = [
    'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_admin_0_countries.geojson',
    'https://cdn.jsdelivr.net/gh/nvkelso/natural-earth-vector/geojson/ne_110m_admin_0_countries.geojson',
  ];

  static const String _cacheFileName = 'seyyah_ne_110m_countries.geojson';

  /// Natural Earth verisindeki birkaç bilinen ISO_A2 eksikliği için
  /// (ör. Fransa, Norveç "-99" döner) manuel eşleme.
  static const Map<String, String> _nameToIsoFallback = {
    'france': 'FR',
    'norway': 'NO',
    'kosovo': 'XK',
    'somaliland': 'SO',
    'northern cyprus': 'CY',
  };

  Future<String?> _readCache() async {
    try {
      final dir = await getApplicationSupportDirectory();
      final file = File('${dir.path}/$_cacheFileName');
      if (await file.exists()) {
        return file.readAsString();
      }
    } catch (_) {
      // Önbellek okunamazsa sessizce yeniden indirmeye düş.
    }
    return null;
  }

  Future<void> _writeCache(String content) async {
    try {
      final dir = await getApplicationSupportDirectory();
      final file = File('${dir.path}/$_cacheFileName');
      await file.writeAsString(content);
    } catch (_) {
      // Yazılamazsa önemli değil; bir sonraki açılışta tekrar indirilir.
    }
  }

  Future<String?> _fetchRemote() async {
    for (final url in naturalEarthUrls) {
      try {
        final response = await http
            .get(Uri.parse(url))
            .timeout(const Duration(seconds: 20));
        if (response.statusCode == 200) {
          return response.body;
        }
      } catch (_) {
        // Bir sonraki alternatif URL'yi dene.
        continue;
      }
    }
    return null;
  }

  /// country_id (ISO2) -> o ülkeye ait çokgen (polygon) listesi.
  /// Her çokgen, LatLng noktalarından oluşan tek bir halka olarak döner.
  Future<Map<String, List<List<LatLng>>>> loadCountryPolygons() async {
    String? raw = await _readCache();
    raw ??= await _fetchRemote();
    if (raw == null) return {};

    // Arka planda önbelleğe yaz (indirmeyse) — hata olursa yut.
    unawaited(_writeCache(raw));

    try {
      final data = jsonDecode(raw) as Map<String, dynamic>;
      final features = data['features'] as List<dynamic>? ?? [];
      final result = <String, List<List<LatLng>>>{};

      for (final feature in features) {
        final props = feature['properties'] as Map<String, dynamic>? ?? {};
        String? iso2 = (props['ISO_A2'] as String?)?.toUpperCase();
        if (iso2 == null || iso2 == '-99' || iso2.isEmpty) {
          final name = (props['NAME'] as String? ?? props['NAME_LONG'] as String? ?? '')
              .toLowerCase();
          iso2 = _nameToIsoFallback[name];
        }
        if (iso2 == null) continue;

        final geometry = feature['geometry'] as Map<String, dynamic>?;
        if (geometry == null) continue;
        final type = geometry['type'] as String?;
        final coords = geometry['coordinates'];

        final rings = <List<LatLng>>[];
        if (type == 'Polygon') {
          rings.addAll(_ringsFromPolygon(coords as List<dynamic>));
        } else if (type == 'MultiPolygon') {
          for (final polygon in (coords as List<dynamic>)) {
            rings.addAll(_ringsFromPolygon(polygon as List<dynamic>));
          }
        }

        if (rings.isNotEmpty) {
          result.putIfAbsent(iso2, () => []).addAll(rings);
        }
      }

      return result;
    } catch (_) {
      return {};
    }
  }

  List<List<LatLng>> _ringsFromPolygon(List<dynamic> polygonCoords) {
    // GeoJSON Polygon coordinates: [ [ [lng, lat], ... ] (dış halka), [iç halkalar]... ]
    // Basitlik için sadece dış halkayı (ilk halka) kullanıyoruz.
    if (polygonCoords.isEmpty) return [];
    final outer = polygonCoords.first as List<dynamic>;
    final points = outer.map((p) {
      final pair = p as List<dynamic>;
      final lng = (pair[0] as num).toDouble();
      final lat = (pair[1] as num).toDouble();
      return LatLng(lat, lng);
    }).toList();
    return [points];
  }
}
