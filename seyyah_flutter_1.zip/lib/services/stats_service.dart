import '../data/database_helper.dart';
import '../models/city.dart';
import '../models/continent.dart';
import '../models/country.dart';
import '../models/province.dart';

/// Ham veritabanı satırlarını modele çevirip yüzde hesaplarını üreten
/// servis katmanı. Tüm yüzdeler "sayı bazlı" hesaplanır:
///
///   yüzde = (gezilen şehir sayısı / toplam şehir sayısı) * 100
///
/// Bu mantık dünya, kıta ve ülke seviyelerinde tutarlı biçimde uygulanır:
/// bir ülkenin şehirleri toplamı üzerinden ülke yüzdesi, bir kıtanın tüm
/// ülkelerinin şehirleri toplamı üzerinden kıta yüzdesi, tüm dünyanın
/// şehirleri toplamı üzerinden dünya yüzdesi hesaplanır.
class StatsService {
  final DatabaseHelper _db = DatabaseHelper.instance;

  Future<List<Continent>> getContinents() async {
    final rows = await _db.getContinents();
    return rows.map(Continent.fromMap).toList();
  }

  Future<List<Country>> getCountries({String? continentId}) async {
    final rows = await _db.getCountries(continentId: continentId);
    return rows.map(Country.fromMap).toList();
  }

  Future<Country?> getCountry(String countryId) async {
    final row = await _db.getCountry(countryId);
    return row == null ? null : Country.fromMap(row);
  }

  Future<List<City>> getCities(String countryId, {String? search}) async {
    final rows = await _db.getCities(countryId: countryId, searchQuery: search);
    return rows.map(City.fromDb).toList();
  }

  /// Bir ülkenin illeri (varsa; yoksa boş liste döner ve o ülke eski
  /// davranışla — ülke -> düz şehir listesi — gösterilir).
  Future<List<Province>> getProvinces(String countryId) async {
    final rows = await _db.getProvinces(countryId: countryId);
    return rows.map(Province.fromMap).toList();
  }

  Future<Province?> getProvince(String provinceId) async {
    final row = await _db.getProvince(provinceId);
    return row == null ? null : Province.fromMap(row);
  }

  Future<List<City>> getDistricts(String provinceId, {String? search}) async {
    final rows = await _db.getDistricts(provinceId: provinceId, searchQuery: search);
    return rows.map(City.fromDb).toList();
  }

  Future<List<ProvinceStats>> getProvinceStatsList(String countryId) async {
    final provinces = await getProvinces(countryId);
    final totalsRows = await _db.getProvinceTotals(countryId: countryId);
    final totalsById = {
      for (final row in totalsRows) row['province_id'] as String: row,
    };

    return provinces.map((province) {
      final row = totalsById[province.id];
      final total = (row?['total_cities'] as int?) ?? 0;
      final visited = (row?['visited_cities'] as int?) ?? 0;
      return ProvinceStats(
        province: province,
        totalDistricts: total,
        visitedDistricts: visited,
      );
    }).toList()
      ..sort((a, b) {
        final capitalDiff = (b.province.isCapital ? 1 : 0) - (a.province.isCapital ? 1 : 0);
        return capitalDiff != 0 ? capitalDiff : a.province.name.compareTo(b.province.name);
      });
  }

  Future<ProvinceStats?> getProvinceStats(String provinceId) async {
    final province = await getProvince(provinceId);
    if (province == null) return null;
    final totalsRows = await _db.getProvinceTotals(countryId: province.countryId);
    final row = totalsRows.firstWhere(
      (r) => r['province_id'] == provinceId,
      orElse: () => const {},
    );
    final total = (row['total_cities'] as int?) ?? 0;
    final visited = (row['visited_cities'] as int?) ?? 0;
    return ProvinceStats(province: province, totalDistricts: total, visitedDistricts: visited);
  }

  Future<void> setProvinceAllVisited(String provinceId, bool visited) =>
      _db.setProvinceAllVisited(provinceId, visited);

  /// Dünya genelinde (world) toplam ve gezilen şehir sayısı + yüzde.
  Future<({int total, int visited, double percent})> getWorldStats() async {
    final (total, visited) = await _db.getWorldTotals();
    final percent = total == 0 ? 0.0 : (visited / total) * 100;
    return (total: total, visited: visited, percent: percent);
  }

  Future<List<ContinentStats>> getContinentStatsList() async {
    final continents = await getContinents();
    final totalsRows = await _db.getContinentTotals();
    final totalsById = {
      for (final row in totalsRows) row['continent_id'] as String: row,
    };

    return continents.map((continent) {
      final row = totalsById[continent.id];
      final total = (row?['total_cities'] as int?) ?? 0;
      final visited = (row?['visited_cities'] as int?) ?? 0;
      final totalCountries = (row?['total_countries'] as int?) ?? 0;
      final visitedCountries = (row?['visited_countries'] as int?) ?? 0;
      return ContinentStats(
        continent: continent,
        totalCities: total,
        visitedCities: visited,
        totalCountries: totalCountries,
        visitedCountries: visitedCountries,
      );
    }).toList()
      ..sort((a, b) => a.continent.nameTr.compareTo(b.continent.nameTr));
  }

  Future<List<CountryStats>> getCountryStatsList({String? continentId}) async {
    final countries = await getCountries(continentId: continentId);
    final totalsRows = await _db.getCountryTotals(continentId: continentId);
    final totalsById = {
      for (final row in totalsRows) row['country_id'] as String: row,
    };

    return countries.map((country) {
      final row = totalsById[country.id];
      final total = (row?['total_cities'] as int?) ?? 0;
      final visited = (row?['visited_cities'] as int?) ?? 0;
      return CountryStats(
        country: country,
        totalCities: total,
        visitedCities: visited,
      );
    }).toList()
      ..sort((a, b) => a.country.nameTr.compareTo(b.country.nameTr));
  }

  Future<CountryStats?> getCountryStats(String countryId) async {
    final country = await getCountry(countryId);
    if (country == null) return null;
    final totalsRows = await _db.getCountryTotals();
    final row = totalsRows.firstWhere(
      (r) => r['country_id'] == countryId,
      orElse: () => const {},
    );
    final total = (row['total_cities'] as int?) ?? 0;
    final visited = (row['visited_cities'] as int?) ?? 0;
    return CountryStats(country: country, totalCities: total, visitedCities: visited);
  }

  Future<void> setCityVisited(int cityId, bool visited) =>
      _db.setCityVisited(cityId, visited);

  Future<void> setCountryAllVisited(String countryId, bool visited) =>
      _db.setCountryAllVisited(countryId, visited);

  Future<void> resetAllVisited() => _db.resetAllVisited();
}
