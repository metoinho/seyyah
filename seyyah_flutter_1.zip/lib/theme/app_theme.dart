import 'package:flutter/material.dart';

/// SEYYAH marka renkleri.
///
/// Kırmızı tonu, Türk hava yolu markalarında da kullanılan klasik
/// "Türk kırmızısı" (Pantone 186C / Türk bayrağı kırmızısına yakın) referans
/// alınarak seçilmiştir. Bu, herhangi bir markanın logosunun birebir
/// kopyası DEĞİLDİR — SEYYAH'a özgü, özgün bir logo ve ikon seti
/// kullanır; yalnızca renk ailesi ortak bir "Türk kırmızısı" tonudur.
class AppColors {
  AppColors._();

  static const Color seyyahRed = Color(0xFFE30613); // ana marka kırmızısı
  static const Color seyyahRedDark = Color(0xFFB4050F); // koyu vurgu / başlık
  static const Color seyyahRedLight = Color(0xFFFFE5E7); // açık zemin / rozet
  static const Color seyyahRedSurface = Color(0xFFFFF3F4); // kart zemini

  // Sayfa zemini: mavi (#00559F) — beyaz kartlar bu zeminin üzerinde
  // yüzer, öndeki yazılar ve logo kırmızı ailesinde kalır (bkz. AuthScreen
  // ile aynı marka kararı, web sürümündeki --bg/--onblue token'larıyla
  // birebir eşleşir).
  static const Color seyyahBlue = Color(0xFF00559F);
  // Beyaz bir kart olmadan doğrudan mavi zemin üzerine basılan yazı/ikon
  // rengi: aynı kırmızı ailesinden, mavi üzerinde okunaklı kalacak kadar
  // açılmış tonlar.
  static const Color onBlue = Color(0xFFFF7A82);
  static const Color onBlueMuted = Color(0xFFFFC9CC);

  static const Color white = Color(0xFFFFFFFF);
  static const Color offWhite = Color(0xFFFAFAFA);
  // Beyaz kartların içindeki metin rengi: koyu kırmızı (web --ink ile aynı).
  static const Color ink = Color(0xFFA3040F);
  static const Color inkMuted = Color(0xFFB4676C);
  static const Color divider = Color(0xFFEDEDED);

  static const Color unvisited = Color(0xFFE2E2E2);
  static const Color visited = seyyahRed;

  /// 0.0 (hiç gezilmemiş) - 1.0 (tamamen gezilmiş) arasında bir orana göre
  /// açık griden kırmızıya kademeli renk üretir (harita boyama için).
  static Color progressColor(double ratio) {
    final r = ratio.clamp(0.0, 1.0);
    return Color.lerp(unvisited, seyyahRed, r) ?? unvisited;
  }
}

class AppTheme {
  AppTheme._();

  /// SEYYAH'ta tüm metinler için kullanılan yazı tipi ailesi.
  ///
  /// NOT: Trebuchet MS, Microsoft'un tescilli bir fontudur ve uygulama
  /// paketi içine yeniden dağıtılamaz (lisans kısıtlaması). iOS, Trebuchet
  /// MS'i sistemde hazır bulundurduğu için orada gerçek Trebuchet MS ile
  /// görüntülenir. Android'de bu isimde bir font bulunamadığından Flutter
  /// otomatik olarak sistem varsayılan sans-serif fontuna (Roboto) geri
  /// döner. Android'de birebir Trebuchet MS görünümü isteniyorsa, metrik
  /// uyumlu ücretsiz bir alternatif `assets/fonts/` altına eklenip burada
  /// `fontFamily` olarak tanımlanabilir.
  static const String fontFamily = 'Trebuchet MS';

  static ThemeData get light {
    final base = ThemeData(useMaterial3: true, brightness: Brightness.light);

    return base.copyWith(
      scaffoldBackgroundColor: AppColors.seyyahBlue,
      primaryColor: AppColors.seyyahRed,
      fontFamily: fontFamily,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.seyyahRed,
        secondary: AppColors.seyyahRedDark,
        surface: AppColors.white,
        error: AppColors.seyyahRedDark,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        foregroundColor: AppColors.onBlue,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          fontFamily: fontFamily,
          color: AppColors.onBlue,
          fontSize: 22,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.2,
        ),
        iconTheme: IconThemeData(color: AppColors.onBlue),
      ),
      textTheme: base.textTheme.apply(
        fontFamily: fontFamily,
        bodyColor: AppColors.ink,
        displayColor: AppColors.seyyahRed,
      ),
      primaryTextTheme: base.primaryTextTheme.apply(fontFamily: fontFamily),
      iconTheme: const IconThemeData(color: AppColors.seyyahRed),
      dividerTheme: const DividerThemeData(
        color: AppColors.divider,
        thickness: 1,
      ),
      cardTheme: CardThemeData(
        color: AppColors.white,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: AppColors.divider),
        ),
      ),
      listTileTheme: const ListTileThemeData(
        iconColor: AppColors.seyyahRed,
        textColor: AppColors.ink,
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return AppColors.seyyahRed;
          }
          return AppColors.white;
        }),
        side: const BorderSide(color: AppColors.seyyahRed, width: 1.5),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(6),
        ),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected)
              ? AppColors.seyyahRed
              : AppColors.inkMuted,
        ),
        trackColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected)
              ? AppColors.seyyahRedLight
              : AppColors.divider,
        ),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        // Yükleme göstergeleri çoğunlukla doğrudan mavi zemin üzerinde
        // görünür (bkz. AppColors.seyyahBlue) — bu yüzden koyu değil,
        // mavi üzerinde okunaklı açık kırmızı kullanılır. (StatHeroCard
        // kendi yüzde halkası için beyaz/pembe kart zemininde ayrıca
        // AppColors.seyyahRed'i doğrudan belirtir, buradan etkilenmez.)
        color: AppColors.onBlue,
        linearTrackColor: AppColors.unvisited,
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: AppColors.seyyahRed,
        foregroundColor: AppColors.white,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.seyyahRed,
          foregroundColor: AppColors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.seyyahRed,
          side: const BorderSide(color: AppColors.seyyahRed),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(foregroundColor: AppColors.seyyahRed),
      ),
      chipTheme: base.chipTheme.copyWith(
        backgroundColor: AppColors.seyyahRedSurface,
        labelStyle: const TextStyle(
          color: AppColors.seyyahRedDark,
          fontWeight: FontWeight.w700,
        ),
        side: BorderSide.none,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.offWhite,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.seyyahRed, width: 1.5),
        ),
        hintStyle: const TextStyle(color: AppColors.inkMuted),
      ),
    );
  }
}
