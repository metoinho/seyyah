/// Uygulama genelinde kullanılan sabitler.
class AppConstants {
  AppConstants._();

  static const String appName = 'SEYYAH';
  static const String appTagline = "Dünya'yı adım adım keşfet.";
}
