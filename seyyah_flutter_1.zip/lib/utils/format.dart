/// Yüzde değerlerini uygulama genelinde TUTARLI biçimde gösterir: her
/// zaman tek ondalık basamak, Türkçe virgüllü ayraç (ör. "0,0", "7,4",
/// "15,0" — asla "0.4" ya da ondalıksız "15").
String fmtPercent(double percent) {
  final clamped = percent < 0 ? 0.0 : percent;
  return clamped.toStringAsFixed(1).replaceAll('.', ',');
}
