import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../utils/format.dart';

/// "%12" gibi küçük, kırmızı-beyaz bir yüzde rozeti.
class ProgressBadge extends StatelessWidget {
  final double percent;
  final bool compact;

  const ProgressBadge({super.key, required this.percent, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final ratio = (percent / 100).clamp(0.0, 1.0);
    final color = AppColors.progressColor(ratio);
    final isZero = percent <= 0;

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 8 : 12,
        vertical: compact ? 3 : 6,
      ),
      decoration: BoxDecoration(
        color: isZero ? AppColors.offWhite : AppColors.seyyahRedSurface,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: isZero ? AppColors.divider : color.withOpacity(0.5),
        ),
      ),
      child: Text(
        '%${fmtPercent(percent)}',
        style: TextStyle(
          fontSize: compact ? 12 : 13,
          fontWeight: FontWeight.w900,
          color: isZero ? AppColors.inkMuted : AppColors.seyyahRedDark,
        ),
      ),
    );
  }
}

/// Bir liste satırının sonunda kullanılan ince, yatay ilerleme çubuğu.
class ProgressBar extends StatelessWidget {
  final double percent;

  const ProgressBar({super.key, required this.percent});

  @override
  Widget build(BuildContext context) {
    final ratio = (percent / 100).clamp(0.0, 1.0);
    return ClipRRect(
      borderRadius: BorderRadius.circular(999),
      child: LinearProgressIndicator(
        value: ratio,
        minHeight: 6,
        backgroundColor: AppColors.unvisited.withOpacity(0.4),
        valueColor: AlwaysStoppedAnimation(AppColors.progressColor(ratio)),
      ),
    );
  }
}
