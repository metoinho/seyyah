import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../utils/format.dart';

/// Ana ekranda kullanılan büyük, dairesel ilerlemeli istatistik kartı.
class StatHeroCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final double percent;
  final VoidCallback? onTap;

  const StatHeroCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.percent,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final ratio = (percent / 100).clamp(0.0, 1.0);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppColors.seyyahRedSurface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.seyyahRedLight),
        ),
        child: Row(
          children: [
            SizedBox(
              width: 88,
              height: 88,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 88,
                    height: 88,
                    child: CircularProgressIndicator(
                      value: ratio,
                      strokeWidth: 8,
                      backgroundColor: AppColors.unvisited.withOpacity(0.5),
                      valueColor: const AlwaysStoppedAnimation(AppColors.seyyahRed),
                    ),
                  ),
                  Text(
                    '%${fmtPercent(percent)}',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: AppColors.seyyahRedDark,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: AppColors.seyyahRedDark,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(fontSize: 13, color: AppColors.inkMuted),
                  ),
                ],
              ),
            ),
            if (onTap != null)
              const Icon(Icons.chevron_right, color: AppColors.seyyahRed),
          ],
        ),
      ),
    );
  }
}

/// Kıta / ülke listelerinde satır olarak kullanılan kart.
class StatListTile extends StatelessWidget {
  final String leadingEmoji;
  final String? leadingImagePath;
  final String title;
  final String subtitle;
  final double percent;
  final VoidCallback onTap;
  final Widget? trailingExtra;
  // Kıta satırlarında logo %50 daha büyük, isim ve alt satır kalın
  // gösterilir (bkz. anasayfadaki "Kıtalar" listesi).
  final bool emphasized;

  const StatListTile({
    super.key,
    required this.leadingEmoji,
    this.leadingImagePath,
    required this.title,
    required this.subtitle,
    required this.percent,
    required this.onTap,
    this.trailingExtra,
    this.emphasized = false,
  });

  @override
  Widget build(BuildContext context) {
    final imageSize = emphasized ? 51.0 : 34.0;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              leadingImagePath != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.asset(
                        leadingImagePath!,
                        width: imageSize,
                        height: imageSize,
                        fit: BoxFit.cover,
                      ),
                    )
                  : Text(leadingEmoji, style: const TextStyle(fontSize: 26)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontWeight: emphasized ? FontWeight.w900 : FontWeight.w700,
                        fontSize: emphasized ? 16 : 15,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 12,
                        color: AppColors.inkMuted,
                        fontWeight: emphasized ? FontWeight.w800 : FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),
              if (trailingExtra != null) ...[trailingExtra!, const SizedBox(width: 8)],
              _PercentPill(percent: percent),
              const SizedBox(width: 4),
              const Icon(Icons.chevron_right, size: 20, color: AppColors.inkMuted),
            ],
          ),
        ),
      ),
    );
  }
}

class _PercentPill extends StatelessWidget {
  final double percent;
  const _PercentPill({required this.percent});

  @override
  Widget build(BuildContext context) {
    final ratio = (percent / 100).clamp(0.0, 1.0);
    final color = AppColors.progressColor(ratio);
    final isZero = percent <= 0;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: isZero ? AppColors.offWhite : AppColors.seyyahRedSurface,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: isZero ? AppColors.divider : color.withOpacity(0.5)),
      ),
      child: Text(
        '%${fmtPercent(percent)}',
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w900,
          color: isZero ? AppColors.inkMuted : AppColors.seyyahRedDark,
        ),
      ),
    );
  }
}
