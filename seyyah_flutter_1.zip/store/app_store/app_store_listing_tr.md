# Apple App Store Connect — Mağaza Listeleme Metinleri (Taslak)

## Uygulama Adı (30 karakter sınırı)
```
SEYYAH
```

## Alt Başlık / Subtitle (30 karakter sınırı)
```
Dünyayı adım adım keşfet
```

## Tanıtım Metni / Promotional Text (170 karakter, App Store inceleme
gerekmeden güncellenebilir)
```
Gezdiğin şehirleri işaretle, dünyanın, kıtaların ve ülkelerin yüzde
kaçını gezdiğini anında gör. Yeni hedefler belirle, seyahat rotanı planla!
```

## Açıklama (4000 karakter sınırı)
```
SEYYAH ile dünyayı adım adım keşfet!

Gezdiğin şehirleri tek tek işaretle, SEYYAH senin için otomatik olarak
hesaplasın: Dünyanın yüzde kaçını gezdin? Peki ya Avrupa'nın, Asya'nın,
Afrika'nın? Türkiye'nin ya da gitmeyi hayal ettiğin herhangi bir ülkenin?

ÖZELLİKLER
• Dünya → Kıta → Ülke → Şehir sıralamasıyla kolay gezinme
• Her seviyede anlık, otomatik yüzde hesaplama
• Binlerce şehir içeren kapsamlı, sürekli genişleyen veri tabanı
• Görsel dünya haritası ile gezdiğin bölgeleri renkli görme
• Hızlı arama ile istediğin şehri/ülkeyi saniyeler içinde bulma
• Tüm verilerin yalnızca senin cihazında saklanır

Dünyayı keşfetmeye bugün SEYYAH ile devam et!
```

## Anahtar Kelimeler (100 karakter, virgülle ayrılmış)
```
seyahat,gezi,dünya haritası,ülkeler,şehirler,travel,tracker,bucket list,gezgin
```

## Kategori
```
Birincil: Travel (Seyahat)
İkincil: Lifestyle (Yaşam Tarzı) — opsiyonel
```

## Gerekli Grafikler
- **Uygulama ikonu:** 1024×1024 px, PNG, alfa kanalı YOK (arka planı SAYDAM
  OLMAMALI) → `assets/images/app_icon_1024.png` doğrudan kullanılabilir.
- **Ekran görüntüleri:** Her desteklenen cihaz boyutu için ayrı seri
  gerekir (ör. 6.7" iPhone, 6.5" iPhone, iPad Pro 12.9" — App Store
  Connect'in istediği güncel boyut listesine bakın). Uygulamayı
  Xcode Simulator'da çalıştırıp `Cmd+S` ile ekran görüntüsü alabilirsiniz.

## App Privacy (Gizlilik Bilgi Formu)
Uygulama giriş ekranında bir **isim** ve **e-posta adresi** topluyor ve
doğrulama kodu göndermek için bunları Firebase (Firestore) ve EmailJS'e
iletiyor. App Store Connect'teki "App Privacy" bölümünde "Data Not
Collected" YERİNE, "Contact Info" kategorisi altında **Email Address**
ve **Name** verilerini, kullanım amacı olarak **App Functionality**
(hesap oluşturma/doğrulama) seçerek beyan edin. Bkz. güncel
`privacy_policy_tr.md`.

## Gizlilik Politikası URL'si
Apple, gönderim sırasında herkese açık bir gizlilik politikası URL'si
zorunlu tutar (bkz. `store/privacy_policy/privacy_policy_tr.md`).

## Export Compliance (Şifreleme Beyanı)
SEYYAH, standart HTTPS dışında özel bir şifreleme kullanmıyorsa, App
Store Connect'teki şifreleme sorusuna genellikle "Uygulama yalnızca
istisna kapsamındaki şifrelemeyi (HTTPS/TLS) kullanıyor" yanıtı uygundur
— ancak bunu kendi hukuki/uyum sorumluluğunuz kapsamında teyit edin.
