# Google Play Console — Mağaza Listeleme Metinleri (Taslak)

## Uygulama Adı (30 karakter sınırı)
```
SEYYAH
```

## Kısa Açıklama (80 karakter sınırı)
```
Dünyayı, kıtaları, ülkeleri ve şehirleri işaretle; ne kadarını gezdiğini gör.
```
(76 karakter)

## Tam Açıklama (4000 karakter sınırı)
```
SEYYAH ile dünyayı adım adım keşfet!

Gezdiğin şehirleri tek tek işaretle, SEYYAH senin için otomatik olarak
hesaplasın: Dünyanın yüzde kaçını gezdin? Peki ya Avrupa'nın, Asya'nın,
Afrika'nın? Türkiye'nin ya da gitmeyi hayal ettiğin herhangi bir ülkenin?

ÖZELLİKLER
• Dünya → Kıta → Ülke → Şehir sıralamasıyla kolay gezinme
• Her seviyede anlık, otomatik yüzde hesaplama
• Binlerce şehir içeren kapsamlı, sürekli genişleyen veri tabanı
• Görsel dünya haritası ile gezdiğin bölgeleri renkli görme
• Hızlı arama ile istediğin şehri/ülkeyi saniyeler içinde bulma
• Tüm verilerin yalnızca senin cihazında saklanır — gizliliğine saygılı

SEYYAH KİMLER İÇİN?
Gezginler, sık seyahat edenler, "kaç ülke gördüm" merakı olanlar ve
bir sonraki seyahat hedefini planlamak isteyen herkes için.

Dünyayı keşfetmeye bugün SEYYAH ile devam et!
```

## Kategori
```
Seyahat ve Yerel (Travel & Local)
```

## Etiketler / Anahtar Kelimeler (öneri)
```
seyahat, gezi, dünya haritası, ülkeler, şehirler, seyahat takibi,
gezilen ülkeler, bucket list, travel tracker
```

## Grafik Varlıkları — Gereksinimler (Play Console)
- **Uygulama ikonu:** 512×512 px, PNG, 32-bit (alfa kanalı YOK) →
  `assets/images/app_icon_1024.png` dosyasını 512×512'e küçültüp kullanın.
- **Öne çıkan görsel (Feature graphic):** 1024×500 px, JPG/PNG (bu proje
  içinde HAZIR DEĞİL — logo + "SEYYAH" wordmark + kısa slogan içeren bir
  banner tasarlamanız gerekir).
- **Ekran görüntüleri:** Telefon için en az 2, önerilen 4-8 adet
  (16:9 veya 9:16, min. 320px, maks. 3840px kenar). Uygulamayı gerçek bir
  cihaz veya emülatörde çalıştırıp ana ekran, kıta ekranı, ülke/şehir
  listesi ve harita ekranından görüntü alın.

## İçerik Derecelendirmesi (Content Rating)
Uygulamada şiddet, cinsellik, kullanıcı üretimi içerik veya sosyal
özellik bulunmuyorsa Play Console'daki IARC anketinde "Herkes / Everyone"
seviyesine denk gelen yanıtlar verilmesi beklenir. Anketi siz doldurmalısınız.

## Veri Güvenliği Formu (Data Safety)
Uygulama giriş ekranında bir **isim** ve **e-posta adresi** topluyor ve
bunları doğrulama kodu göndermek için Firebase (Firestore) ve EmailJS'e
iletiyor. Play Console'daki "Data safety" formunda:
- "Bu uygulama kullanıcı verisi topluyor" → EVET,
- Toplanan veri türü: **E-posta adresi** ve **İsim** (Personal info),
- Amaç: **Account management** (hesap/kimlik doğrulama),
- Üçüncü taraflarla paylaşım: EVET — Firebase (Google) ve EmailJS,
- Şifreleme: veri aktarım sırasında şifreleniyor (HTTPS),
- Silme: kullanıcı uygulamayı kaldırdığında cihazdaki veri silinir;
  sunucu tarafındaki kayıt için kullanıcıya `store/privacy_policy/
  privacy_policy_tr.md` içindeki iletişim adresinden ulaşabileceğini
  belirtin.
seçeneklerini işaretleyin. Bkz. güncel `privacy_policy_tr.md`.
