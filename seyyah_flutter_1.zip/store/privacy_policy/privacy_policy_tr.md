# SEYYAH Gizlilik Politikası

*Son güncelleme: 16 Eylül 2026*

Bu gizlilik politikası, "SEYYAH" mobil uygulamasının ("Uygulama", "SEYYAH")
kullanıcı verilerini nasıl işlediğini açıklar. SEYYAH, [ŞİRKET/GELİŞTİRİCİ
ADINI GİRİN] tarafından geliştirilmiştir.

## 1. Topladığımız Veriler

SEYYAH, giriş ekranında sizden bir **isim** ve bir **e-posta adresi**
ister ve size bir doğrulama kodu göndermek için bunları aşağıdaki
"Üçüncü Taraf Hizmetler" bölümünde açıklanan servislere iletir.

Aşağıdakiler ise yalnızca cihazınızda YEREL olarak saklanır, hiçbir
sunucuya gönderilmez:

- Gezdiğiniz olarak işaretlediğiniz şehirler ve tarihleri,
- Uygulama ayarlarınız.

Bu yerel veriler, Uygulama'yı kaldırdığınızda cihazınızdan silinir.

## 2. Üçüncü Taraf Hizmetler

- **Firebase (Google) — Firestore:** Giriş sırasında isim ve e-posta
  adresiniz, doğrulama kodunuzu geçici olarak saklamak ve hesabınızı
  tanımak için Google'ın Firebase (Firestore) veritabanına iletilir.
- **EmailJS:** Doğrulama kodunu içeren e-postayı size göndermek için
  e-posta adresiniz EmailJS servisine iletilir.
- **Dünya Haritası özelliği:** Ülke sınırlarını göstermek için internet
  üzerinden genel/kamuya açık bir coğrafi sınır veri setini (Natural
  Earth, kamu malı) indirir. Bu indirme sırasında cihazınızın IP adresi,
  veriyi barındıran sunucu(lar) tarafından standart web sunucusu günlük
  kayıtları kapsamında görülebilir; bu, bizim kontrolümüzde değildir ve
  ayrıca kişisel veri toplamak amacıyla yapılmaz.

[GELİŞTİRİCİ NOTU: İleride reklam, analitik (ör. Firebase Analytics/
Crashlytics) veya bildirim (push notification) özelliği eklerseniz, bu
bölümü MUTLAKA güncelleyip ilgili üçüncü taraf sağlayıcıları ve
topladıkları veri türlerini (reklam kimliği, cihaz bilgisi vb.) açıkça
belirtin — Google Play ve App Store, bu tür değişiklikleri "Veri
Güvenliği" / "Gizlilik Bilgi Formu" (Privacy Nutrition Label)
beyanlarınızla eşleşmediğinde uygulamanızı reddedebilir veya
kaldırabilir.]

## 3. Çocukların Gizliliği

SEYYAH, belirli bir yaş grubunu hedeflemez ve bilerek 13 yaşından küçük
çocuklardan kişisel veri toplamaz.

## 4. Veri Güvenliği

Seyahat verileriniz cihazınızda kaldığı için bunların güvenliği büyük
ölçüde cihazınızın kendi güvenlik önlemlerine bağlıdır. İsim ve e-posta
adresiniz, yukarıda belirtilen servislere şifreli bağlantı (HTTPS)
üzerinden iletilir ve reklam amacıyla üçüncü taraflarla paylaşılmaz veya
satılmaz.

## 5. Haklarınız

Uygulama içindeki "Ayarlar > Tüm işaretleri sıfırla" seçeneğiyle
verilerinizi istediğiniz zaman silebilirsiniz. Uygulamayı cihazınızdan
kaldırmak tüm yerel verileri de siler.

## 6. Bize Ulaşın

Sorularınız için: mete@roipublic.com

---

**ÖNEMLİ NOT (geliştirici için):** Bu belge bir taslaktır. Google Play
Console ve Apple App Store Connect, yayınlamadan önce halka açık,
barındırılan (hosted) bir gizlilik politikası URL'si ister. Bu metni:

1. Köşeli parantez içindeki alanları doldurun,
2. Bir web sayfası olarak yayınlayın (ör. şirket web siteniz, GitHub
   Pages, Notion herkese açık sayfa vb.),
3. Elde ettiğiniz URL'yi hem Play Console'da ("App content" >
   "Privacy policy") hem de App Store Connect'te ilgili alana girin.
