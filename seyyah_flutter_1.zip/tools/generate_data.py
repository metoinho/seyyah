#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SEYYAH başlangıç veri seti üretici.

Bu script; kıta, ülke ve şehir verilerini tek bir yerden tanımlayıp
`assets/data/continents.json`, `assets/data/countries.json` ve
`assets/data/cities.json` dosyalarını üretir.

Not: Şehir listeleri, bu ortamda büyük dış veri kaynaklarına (GeoNames vb.)
erişim mümkün olmadığı için elle derlenmiş, her ülkenin başkenti ve bilinen
başlıca şehirlerinden oluşan bir BAŞLANGIÇ veri setidir. Uygulama, daha
kapsamlı resmi bir veri seti (ör. GeoNames CSV) ile
`tools/import_geonames.py` aracılığıyla genişletilebilecek şekilde
tasarlanmıştır (bkz. README).
"""
import json
import os
import re
import unicodedata

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BASE, "assets", "data")
os.makedirs(OUT_DIR, exist_ok=True)

# ---------------------------------------------------------------------------
# 1) KITALAR
# ---------------------------------------------------------------------------
CONTINENTS = [
    ("AF", "Afrika", "Africa", "🌍"),
    ("AS", "Asya", "Asia", "🌏"),
    ("EU", "Avrupa", "Europe", "🌍"),
    ("NA", "Kuzey Amerika", "North America", "🌎"),
    ("SA", "Güney Amerika", "South America", "🌎"),
    ("OC", "Okyanusya", "Oceania", "🌏"),
    ("AN", "Antarktika", "Antarctica", "🧊"),
]

# ---------------------------------------------------------------------------
# 2) ÜLKELER  (iso2, name_tr, name_en, continent_id, capital)
# ---------------------------------------------------------------------------
COUNTRIES = [
    # --- AFRİKA ---
    ("DZ", "Cezayir", "Algeria", "AF", "Cezayir (Algiers)"),
    ("AO", "Angola", "Angola", "AF", "Luanda"),
    ("BJ", "Benin", "Benin", "AF", "Porto-Novo"),
    ("BW", "Botsvana", "Botswana", "AF", "Gaborone"),
    ("BF", "Burkina Faso", "Burkina Faso", "AF", "Ouagadougou"),
    ("BI", "Burundi", "Burundi", "AF", "Gitega"),
    ("CV", "Cabo Verde", "Cabo Verde", "AF", "Praia"),
    ("CM", "Kamerun", "Cameroon", "AF", "Yaounde"),
    ("CF", "Orta Afrika Cumhuriyeti", "Central African Republic", "AF", "Bangui"),
    ("TD", "Çad", "Chad", "AF", "N'Djamena"),
    ("KM", "Komorlar", "Comoros", "AF", "Moroni"),
    ("CG", "Kongo Cumhuriyeti", "Republic of the Congo", "AF", "Brazzaville"),
    ("CD", "Demokratik Kongo Cumhuriyeti", "DR Congo", "AF", "Kinshasa"),
    ("CI", "Fildişi Sahili", "Côte d'Ivoire", "AF", "Yamoussoukro"),
    ("DJ", "Cibuti", "Djibouti", "AF", "Djibouti"),
    ("EG", "Mısır", "Egypt", "AF", "Kahire (Cairo)"),
    ("GQ", "Ekvator Ginesi", "Equatorial Guinea", "AF", "Malabo"),
    ("ER", "Eritre", "Eritrea", "AF", "Asmara"),
    ("SZ", "Esvatini", "Eswatini", "AF", "Mbabane"),
    ("ET", "Etiyopya", "Ethiopia", "AF", "Addis Ababa"),
    ("GA", "Gabon", "Gabon", "AF", "Libreville"),
    ("GM", "Gambiya", "Gambia", "AF", "Banjul"),
    ("GH", "Gana", "Ghana", "AF", "Accra"),
    ("GN", "Gine", "Guinea", "AF", "Conakry"),
    ("GW", "Gine-Bissau", "Guinea-Bissau", "AF", "Bissau"),
    ("KE", "Kenya", "Kenya", "AF", "Nairobi"),
    ("LS", "Lesoto", "Lesotho", "AF", "Maseru"),
    ("LR", "Liberya", "Liberia", "AF", "Monrovia"),
    ("LY", "Libya", "Libya", "AF", "Trablus (Tripoli)"),
    ("MG", "Madagaskar", "Madagascar", "AF", "Antananarivo"),
    ("MW", "Malavi", "Malawi", "AF", "Lilongwe"),
    ("ML", "Mali", "Mali", "AF", "Bamako"),
    ("MR", "Moritanya", "Mauritania", "AF", "Nouakchott"),
    ("MU", "Mauritius", "Mauritius", "AF", "Port Louis"),
    ("MA", "Fas", "Morocco", "AF", "Rabat"),
    ("MZ", "Mozambik", "Mozambique", "AF", "Maputo"),
    ("NA", "Namibya", "Namibia", "AF", "Windhoek"),
    ("NE", "Nijer", "Niger", "AF", "Niamey"),
    ("NG", "Nijerya", "Nigeria", "AF", "Abuja"),
    ("RW", "Ruanda", "Rwanda", "AF", "Kigali"),
    ("ST", "Sao Tome ve Principe", "Sao Tome and Principe", "AF", "Sao Tome"),
    ("SN", "Senegal", "Senegal", "AF", "Dakar"),
    ("SC", "Seyşeller", "Seychelles", "AF", "Victoria"),
    ("SL", "Sierra Leone", "Sierra Leone", "AF", "Freetown"),
    ("SO", "Somali", "Somalia", "AF", "Mogadişu (Mogadishu)"),
    ("ZA", "Güney Afrika", "South Africa", "AF", "Pretoria"),
    ("SS", "Güney Sudan", "South Sudan", "AF", "Juba"),
    ("SD", "Sudan", "Sudan", "AF", "Hartum (Khartoum)"),
    ("TZ", "Tanzanya", "Tanzania", "AF", "Dodoma"),
    ("TG", "Togo", "Togo", "AF", "Lome"),
    ("TN", "Tunus", "Tunisia", "AF", "Tunus (Tunis)"),
    ("UG", "Uganda", "Uganda", "AF", "Kampala"),
    ("ZM", "Zambiya", "Zambia", "AF", "Lusaka"),
    ("ZW", "Zimbabve", "Zimbabwe", "AF", "Harare"),
    ("EH", "Batı Sahra", "Western Sahara", "AF", "El Aaiún"),

    # --- ASYA ---
    ("AF", "Afganistan", "Afghanistan", "AS", "Kabil (Kabul)"),
    ("AM", "Ermenistan", "Armenia", "AS", "Erivan (Yerevan)"),
    ("AZ", "Azerbaycan", "Azerbaijan", "AS", "Bakü (Baku)"),
    ("BH", "Bahreyn", "Bahrain", "AS", "Manama"),
    ("BD", "Bangladeş", "Bangladesh", "AS", "Dakka (Dhaka)"),
    ("BT", "Bhutan", "Bhutan", "AS", "Thimphu"),
    ("BN", "Brunei", "Brunei", "AS", "Bandar Seri Begawan"),
    ("KH", "Kamboçya", "Cambodia", "AS", "Phnom Penh"),
    ("CN", "Çin", "China", "AS", "Pekin (Beijing)"),
    ("CY", "Kıbrıs", "Cyprus", "AS", "Lefkoşa (Nicosia)"),
    ("GE", "Gürcistan", "Georgia", "AS", "Tiflis (Tbilisi)"),
    ("IN", "Hindistan", "India", "AS", "Yeni Delhi"),
    ("ID", "Endonezya", "Indonesia", "AS", "Jakarta"),
    ("IR", "İran", "Iran", "AS", "Tahran (Tehran)"),
    ("IQ", "Irak", "Iraq", "AS", "Bağdat (Baghdad)"),
    ("IL", "İsrail", "Israel", "AS", "Kudüs (Jerusalem)"),
    ("JP", "Japonya", "Japan", "AS", "Tokyo"),
    ("JO", "Ürdün", "Jordan", "AS", "Amman"),
    ("KZ", "Kazakistan", "Kazakhstan", "AS", "Astana"),
    ("KW", "Kuveyt", "Kuwait", "AS", "Kuveyt (Kuwait City)"),
    ("KG", "Kırgızistan", "Kyrgyzstan", "AS", "Bişkek (Bishkek)"),
    ("LA", "Laos", "Laos", "AS", "Vientiane"),
    ("LB", "Lübnan", "Lebanon", "AS", "Beyrut (Beirut)"),
    ("MY", "Malezya", "Malaysia", "AS", "Kuala Lumpur"),
    ("MV", "Maldivler", "Maldives", "AS", "Male"),
    ("MN", "Moğolistan", "Mongolia", "AS", "Ulan Batur (Ulaanbaatar)"),
    ("MM", "Myanmar", "Myanmar", "AS", "Naypyidaw"),
    ("NP", "Nepal", "Nepal", "AS", "Katmandu (Kathmandu)"),
    ("KP", "Kuzey Kore", "North Korea", "AS", "Pyongyang"),
    ("OM", "Umman", "Oman", "AS", "Maskat (Muscat)"),
    ("PK", "Pakistan", "Pakistan", "AS", "İslamabad (Islamabad)"),
    ("PS", "Filistin", "Palestine", "AS", "Ramallah"),
    ("PH", "Filipinler", "Philippines", "AS", "Manila"),
    ("QA", "Katar", "Qatar", "AS", "Doha"),
    ("SA", "Suudi Arabistan", "Saudi Arabia", "AS", "Riyad (Riyadh)"),
    ("SG", "Singapur", "Singapore", "AS", "Singapur (Singapore)"),
    ("KR", "Güney Kore", "South Korea", "AS", "Seul (Seoul)"),
    ("LK", "Sri Lanka", "Sri Lanka", "AS", "Sri Jayawardenepura Kotte"),
    ("SY", "Suriye", "Syria", "AS", "Şam (Damascus)"),
    ("TW", "Tayvan", "Taiwan", "AS", "Taipei"),
    ("TJ", "Tacikistan", "Tajikistan", "AS", "Duşanbe (Dushanbe)"),
    ("TH", "Tayland", "Thailand", "AS", "Bangkok"),
    ("TL", "Doğu Timor", "Timor-Leste", "AS", "Dili"),
    ("TM", "Türkmenistan", "Turkmenistan", "AS", "Aşkabat (Ashgabat)"),
    ("AE", "Birleşik Arap Emirlikleri", "United Arab Emirates", "AS", "Abu Dabi (Abu Dhabi)"),
    ("UZ", "Özbekistan", "Uzbekistan", "AS", "Taşkent (Tashkent)"),
    ("VN", "Vietnam", "Vietnam", "AS", "Hanoi"),
    ("YE", "Yemen", "Yemen", "AS", "Sana (Sanaa)"),

    # --- AVRUPA ---
    ("AL", "Arnavutluk", "Albania", "EU", "Tiran (Tirana)"),
    ("AD", "Andorra", "Andorra", "EU", "Andorra la Vella"),
    ("AT", "Avusturya", "Austria", "EU", "Viyana (Vienna)"),
    ("BY", "Belarus", "Belarus", "EU", "Minsk"),
    ("BE", "Belçika", "Belgium", "EU", "Brüksel (Brussels)"),
    ("BA", "Bosna Hersek", "Bosnia and Herzegovina", "EU", "Saraybosna (Sarajevo)"),
    ("BG", "Bulgaristan", "Bulgaria", "EU", "Sofya (Sofia)"),
    ("HR", "Hırvatistan", "Croatia", "EU", "Zagreb"),
    ("CZ", "Çekya", "Czechia", "EU", "Prag (Prague)"),
    ("DK", "Danimarka", "Denmark", "EU", "Kopenhag (Copenhagen)"),
    ("EE", "Estonya", "Estonia", "EU", "Talin (Tallinn)"),
    ("FI", "Finlandiya", "Finland", "EU", "Helsinki"),
    ("FR", "Fransa", "France", "EU", "Paris"),
    ("DE", "Almanya", "Germany", "EU", "Berlin"),
    ("GR", "Yunanistan", "Greece", "EU", "Atina (Athens)"),
    ("HU", "Macaristan", "Hungary", "EU", "Budapeşte (Budapest)"),
    ("IS", "İzlanda", "Iceland", "EU", "Reykjavik"),
    ("IE", "İrlanda", "Ireland", "EU", "Dublin"),
    ("IT", "İtalya", "Italy", "EU", "Roma (Rome)"),
    ("XK", "Kosova", "Kosovo", "EU", "Priştine (Pristina)"),
    ("LV", "Letonya", "Latvia", "EU", "Riga"),
    ("LI", "Lihtenştayn", "Liechtenstein", "EU", "Vaduz"),
    ("LT", "Litvanya", "Lithuania", "EU", "Vilnius"),
    ("LU", "Lüksemburg", "Luxembourg", "EU", "Lüksemburg (Luxembourg)"),
    ("MT", "Malta", "Malta", "EU", "Valletta"),
    ("MD", "Moldova", "Moldova", "EU", "Kişinev (Chisinau)"),
    ("MC", "Monako", "Monaco", "EU", "Monako (Monaco)"),
    ("ME", "Karadağ", "Montenegro", "EU", "Podgorica"),
    ("NL", "Hollanda", "Netherlands", "EU", "Amsterdam"),
    ("MK", "Kuzey Makedonya", "North Macedonia", "EU", "Üsküp (Skopje)"),
    ("NO", "Norveç", "Norway", "EU", "Oslo"),
    ("PL", "Polonya", "Poland", "EU", "Varşova (Warsaw)"),
    ("PT", "Portekiz", "Portugal", "EU", "Lizbon (Lisbon)"),
    ("RO", "Romanya", "Romania", "EU", "Bükreş (Bucharest)"),
    ("RU", "Rusya", "Russia", "EU", "Moskova (Moscow)"),
    ("SM", "San Marino", "San Marino", "EU", "San Marino"),
    ("RS", "Sırbistan", "Serbia", "EU", "Belgrad (Belgrade)"),
    ("SK", "Slovakya", "Slovakia", "EU", "Bratislava"),
    ("SI", "Slovenya", "Slovenia", "EU", "Ljubljana"),
    ("ES", "İspanya", "Spain", "EU", "Madrid"),
    ("SE", "İsveç", "Sweden", "EU", "Stockholm"),
    ("CH", "İsviçre", "Switzerland", "EU", "Bern"),
    ("TR", "Türkiye", "Turkey", "EU", "Ankara"),
    ("UA", "Ukrayna", "Ukraine", "EU", "Kiev (Kyiv)"),
    ("GB", "Birleşik Krallık", "United Kingdom", "EU", "Londra (London)"),
    ("VA", "Vatikan", "Vatican City", "EU", "Vatikan"),

    # --- KUZEY AMERİKA ---
    ("AG", "Antigua ve Barbuda", "Antigua and Barbuda", "NA", "Saint John's"),
    ("BS", "Bahamalar", "Bahamas", "NA", "Nassau"),
    ("BB", "Barbados", "Barbados", "NA", "Bridgetown"),
    ("BZ", "Belize", "Belize", "NA", "Belmopan"),
    ("CA", "Kanada", "Canada", "NA", "Ottava (Ottawa)"),
    ("CR", "Kosta Rika", "Costa Rica", "NA", "San Jose"),
    ("CU", "Küba", "Cuba", "NA", "Havana"),
    ("DM", "Dominika", "Dominica", "NA", "Roseau"),
    ("DO", "Dominik Cumhuriyeti", "Dominican Republic", "NA", "Santo Domingo"),
    ("SV", "El Salvador", "El Salvador", "NA", "San Salvador"),
    ("GD", "Grenada", "Grenada", "NA", "St. George's"),
    ("GT", "Guatemala", "Guatemala", "NA", "Guatemala City"),
    ("HT", "Haiti", "Haiti", "NA", "Port-au-Prince"),
    ("HN", "Honduras", "Honduras", "NA", "Tegucigalpa"),
    ("JM", "Jamaika", "Jamaica", "NA", "Kingston"),
    ("MX", "Meksika", "Mexico", "NA", "Meksiko (Mexico City)"),
    ("NI", "Nikaragua", "Nicaragua", "NA", "Managua"),
    ("PA", "Panama", "Panama", "NA", "Panama City"),
    ("KN", "Saint Kitts ve Nevis", "Saint Kitts and Nevis", "NA", "Basseterre"),
    ("LC", "Saint Lucia", "Saint Lucia", "NA", "Castries"),
    ("VC", "Saint Vincent ve Grenadinler", "Saint Vincent and the Grenadines", "NA", "Kingstown"),
    ("TT", "Trinidad ve Tobago", "Trinidad and Tobago", "NA", "Port of Spain"),
    ("US", "Amerika Birleşik Devletleri", "United States", "NA", "Washington D.C."),

    # --- GÜNEY AMERİKA ---
    ("AR", "Arjantin", "Argentina", "SA", "Buenos Aires"),
    ("BO", "Bolivya", "Bolivia", "SA", "Sucre"),
    ("BR", "Brezilya", "Brazil", "SA", "Brasilia"),
    ("CL", "Şili", "Chile", "SA", "Santiago"),
    ("CO", "Kolombiya", "Colombia", "SA", "Bogota"),
    ("EC", "Ekvador", "Ecuador", "SA", "Quito"),
    ("GY", "Guyana", "Guyana", "SA", "Georgetown"),
    ("PY", "Paraguay", "Paraguay", "SA", "Asuncion"),
    ("PE", "Peru", "Peru", "SA", "Lima"),
    ("SR", "Surinam", "Suriname", "SA", "Paramaribo"),
    ("UY", "Uruguay", "Uruguay", "SA", "Montevideo"),
    ("VE", "Venezuela", "Venezuela", "SA", "Karakas (Caracas)"),

    # --- OKYANUSYA ---
    ("AU", "Avustralya", "Australia", "OC", "Canberra"),
    ("FJ", "Fiji", "Fiji", "OC", "Suva"),
    ("KI", "Kiribati", "Kiribati", "OC", "Tarawa"),
    ("MH", "Marshall Adaları", "Marshall Islands", "OC", "Majuro"),
    ("FM", "Mikronezya", "Micronesia", "OC", "Palikir"),
    ("NR", "Nauru", "Nauru", "OC", "Yaren"),
    ("NZ", "Yeni Zelanda", "New Zealand", "OC", "Wellington"),
    ("PW", "Palau", "Palau", "OC", "Ngerulmud"),
    ("PG", "Papua Yeni Gine", "Papua New Guinea", "OC", "Port Moresby"),
    ("WS", "Samoa", "Samoa", "OC", "Apia"),
    ("SB", "Solomon Adaları", "Solomon Islands", "OC", "Honiara"),
    ("TO", "Tonga", "Tonga", "OC", "Nuku'alofa"),
    ("TV", "Tuvalu", "Tuvalu", "OC", "Funafuti"),
    ("VU", "Vanuatu", "Vanuatu", "OC", "Port Vila"),

    # --- ANTARKTİKA (araştırma istasyonları) ---
    ("AQ", "Antarktika", "Antarctica", "AN", "—"),
]

assert len({c[0] + c[3] for c in COUNTRIES}) == len(COUNTRIES), "Yinelenen (iso2, kıta) çifti var"

print(f"Toplam ülke/bölge sayısı: {len(COUNTRIES)}")

# NOT: "NA" hem Namibya'nın ISO2 koduyla hem de Kuzey Amerika kıta
# kimliğiyle çakışan bir tesadüftür. Country.continent_id ve Continent.id
# ayrı alanlar/tablolar olduğu için teknik bir çakışma yaratmaz.

# ---------------------------------------------------------------------------
# 3) ŞEHİRLER (başkent + bilinen başlıca şehirler)
#    Not: Bu, elle derlenmiş bir başlangıç veri setidir (bkz. dosya başı not).
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 2.5) TÜRKİYE İLLERİ (Wikipedia ile doğrulanmış, 81 il)
#     Not: Türkiye'de "şehir" birimi ildir (ilçe ayrımına gidilmedi);
#     diğer ülkelerle aynı şekilde düz bir liste olarak gösterilir.
# ---------------------------------------------------------------------------
TR_PROVINCES = [
    "Adana", "Adıyaman", "Afyonkarahisar", "Ağrı", "Amasya", "Ankara", "Antalya", "Artvin",
    "Aydın", "Balıkesir", "Bilecik", "Bingöl", "Bitlis", "Bolu", "Burdur", "Bursa", "Çanakkale",
    "Çankırı", "Çorum", "Denizli", "Diyarbakır", "Edirne", "Elazığ", "Erzincan", "Erzurum",
    "Eskişehir", "Gaziantep", "Giresun", "Gümüşhane", "Hakkari", "Hatay", "Isparta", "Mersin",
    "İstanbul", "İzmir", "Kars", "Kastamonu", "Kayseri", "Kırklareli", "Kırşehir", "Kocaeli",
    "Konya", "Kütahya", "Malatya", "Manisa", "Kahramanmaraş", "Mardin", "Muğla", "Muş", "Nevşehir",
    "Niğde", "Ordu", "Rize", "Sakarya", "Samsun", "Siirt", "Sinop", "Sivas", "Tekirdağ", "Tokat",
    "Trabzon", "Tunceli", "Şanlıurfa", "Uşak", "Van", "Yozgat", "Zonguldak", "Aksaray", "Bayburt",
    "Karaman", "Kırıkkale", "Batman", "Şırnak", "Bartın", "Ardahan", "Iğdır", "Yalova", "Karabük",
    "Kilis", "Osmaniye", "Düzce",
]

CITIES = {}

# --- AFRİKA ---
CITIES.update({
    "DZ": ["Cezayir", "Oran", "Constantine", "Annaba", "Blida", "Batna", "Sétif", "Tlemcen", "Béjaïa", "Ghardaïa"],
    "AO": ["Luanda", "Huambo", "Lobito", "Benguela", "Lubango", "Malanje", "Namibe", "Soyo"],
    "BJ": ["Porto-Novo", "Cotonou", "Parakou", "Djougou", "Abomey-Calavi", "Abomey"],
    "BW": ["Gaborone", "Francistown", "Molepolole", "Maun", "Kasane", "Serowe"],
    "BF": ["Ouagadougou", "Bobo-Dioulasso", "Koudougou", "Banfora", "Ouahigouya"],
    "BI": ["Gitega", "Bujumbura", "Ngozi", "Rumonge"],
    "CV": ["Praia", "Mindelo", "Santa Maria", "Assomada"],
    "CM": ["Yaounde", "Douala", "Garoua", "Bamenda", "Maroua", "Bafoussam", "Ngaoundéré", "Kribi"],
    "CF": ["Bangui", "Bimbo", "Berbérati", "Carnot"],
    "TD": ["N'Djamena", "Moundou", "Sarh", "Abéché"],
    "KM": ["Moroni", "Mutsamudu", "Fomboni"],
    "CG": ["Brazzaville", "Pointe-Noire", "Dolisie", "Nkayi"],
    "CD": ["Kinshasa", "Lubumbashi", "Mbuji-Mayi", "Kisangani", "Goma", "Bukavu", "Kananga", "Matadi"],
    "CI": ["Yamoussoukro", "Abidjan", "Bouaké", "Daloa", "San-Pédro", "Korhogo"],
    "DJ": ["Djibouti", "Ali Sabieh", "Tadjourah"],
    "EG": ["Kahire (Cairo)", "İskenderiye (Alexandria)", "Giza", "Luksor (Luxor)", "Aswan", "Şarm El-Şeyh (Sharm El Sheikh)", "Hurgada (Hurghada)", "Port Said", "Suez", "Mansoura", "Tanta", "Asyut"],
    "GQ": ["Malabo", "Bata", "Ebebiyín"],
    "ER": ["Asmara", "Keren", "Massawa", "Assab"],
    "SZ": ["Mbabane", "Manzini", "Lobamba"],
    "ET": ["Addis Ababa", "Dire Dawa", "Mekele", "Gondar", "Bahir Dar", "Hawassa", "Jimma"],
    "GA": ["Libreville", "Port-Gentil", "Franceville", "Oyem"],
    "GM": ["Banjul", "Serekunda", "Brikama"],
    "GH": ["Accra", "Kumasi", "Tamale", "Sekondi-Takoradi", "Cape Coast", "Ho"],
    "GN": ["Conakry", "Nzérékoré", "Kankan", "Kindia"],
    "GW": ["Bissau", "Bafatá", "Gabú"],
    "KE": ["Nairobi", "Mombasa", "Kisumu", "Nakuru", "Eldoret", "Malindi", "Naivasha"],
    "LS": ["Maseru", "Teyateyaneng", "Mafeteng"],
    "LR": ["Monrovia", "Gbarnga", "Buchanan"],
    "LY": ["Trablus (Tripoli)", "Bingazi (Benghazi)", "Misrata", "Sabha"],
    "MG": ["Antananarivo", "Toamasina", "Antsirabe", "Mahajanga", "Fianarantsoa"],
    "MW": ["Lilongwe", "Blantyre", "Mzuzu", "Zomba"],
    "ML": ["Bamako", "Sikasso", "Mopti", "Ségou", "Tombuktu (Timbuktu)"],
    "MR": ["Nouakchott", "Nouadhibou", "Kiffa"],
    "MU": ["Port Louis", "Beau Bassin-Rose Hill", "Curepipe"],
    "MA": ["Rabat", "Kazablanka (Casablanca)", "Marakeş (Marrakesh)", "Fas (Fez)", "Tanca (Tangier)", "Agadir", "Meknes", "Essaouira", "Chefchaouen"],
    "MZ": ["Maputo", "Matola", "Beira", "Nampula", "Tete"],
    "NA": ["Windhoek", "Walvis Bay", "Swakopmund", "Oshakati"],
    "NE": ["Niamey", "Zinder", "Maradi", "Agadez"],
    "NG": ["Abuja", "Lagos", "Kano", "İbadan (Ibadan)", "Port Harcourt", "Benin City", "Kaduna", "Enugu", "Jos", "Calabar"],
    "RW": ["Kigali", "Butare", "Gisenyi", "Ruhengeri"],
    "ST": ["Sao Tome", "Santo António"],
    "SN": ["Dakar", "Touba", "Thiès", "Saint-Louis", "Ziguinchor"],
    "SC": ["Victoria", "Anse Boileau"],
    "SL": ["Freetown", "Bo", "Kenema", "Makeni"],
    "SO": ["Mogadişu (Mogadishu)", "Hargeisa", "Kismayo", "Bosaso"],
    "ZA": ["Pretoria", "Johannesburg", "Cape Town", "Durban", "Port Elizabeth", "Bloemfontein", "Soweto", "Stellenbosch"],
    "SS": ["Juba", "Wau", "Malakal"],
    "SD": ["Hartum (Khartoum)", "Omdurman", "Port Sudan", "Kassala"],
    "TZ": ["Dodoma", "Dar es Salaam", "Arusha", "Mwanza", "Zanzibar City", "Tanga"],
    "TG": ["Lome", "Sokodé", "Kara"],
    "TN": ["Tunus (Tunis)", "Sfax", "Sousse", "Kairouan", "Hammamet", "Djerba"],
    "UG": ["Kampala", "Entebbe", "Gulu", "Jinja", "Mbarara"],
    "ZM": ["Lusaka", "Kitwe", "Ndola", "Livingstone"],
    "ZW": ["Harare", "Bulawayo", "Victoria Falls", "Mutare", "Gweru"],
    "EH": ["El Aaiún", "Dakhla"],
})

# --- ASYA ---
CITIES.update({
    "AF": ["Kabil (Kabul)", "Herat", "Mezar-ı Şerif (Mazar-i-Sharif)", "Kandahar", "Cellalabad (Jalalabad)"],
    "AM": ["Erivan (Yerevan)", "Gyumri", "Vanadzor", "Sevan"],
    "AZ": ["Bakü (Baku)", "Gence (Ganja)", "Sumqayıt", "Şeki (Sheki)", "Naftalan"],
    "BH": ["Manama", "Muharraq", "Riffa"],
    "BD": ["Dakka (Dhaka)", "Çitagong (Chittagong)", "Khulna", "Rajshahi", "Sylhet", "Cox's Bazar"],
    "BT": ["Thimphu", "Paro", "Punakha"],
    "BN": ["Bandar Seri Begawan", "Kuala Belait", "Seria"],
    "KH": ["Phnom Penh", "Siem Reap", "Battambang", "Sihanoukville"],
    "CN": ["Pekin (Beijing)", "Şanghay (Shanghai)", "Guangzhou", "Şenzen (Shenzhen)", "Chengdu", "Xi'an", "Hong Kong", "Makao (Macau)", "Hangzhou", "Nanjing", "Wuhan", "Chongqing", "Suzhou", "Guilin", "Lhasa", "Ürümçi (Urumqi)", "Kunming", "Harbin", "Qingdao", "Tianjin"],
    "CY": ["Lefkoşa (Nicosia)", "Limasol (Limassol)", "Larnaka (Larnaca)", "Girne (Kyrenia)", "Baf (Paphos)", "Mağusa (Famagusta)"],
    "GE": ["Tiflis (Tbilisi)", "Batum (Batumi)", "Kutaisi", "Mtsheta (Mtskheta)", "Gori"],
    "IN": ["Yeni Delhi (New Delhi)", "Mumbai", "Bangalore", "Kolkata", "Chennai", "Hyderabad", "Jaipur", "Agra", "Goa", "Varanasi", "Pune", "Amritsar", "Udaipur", "Kochi", "Shimla", "Darjeeling", "Rishikesh"],
    "ID": ["Jakarta", "Surabaya", "Bandung", "Medan", "Bali (Denpasar)", "Ubud", "Yogyakarta", "Makassar", "Palembang", "Lombok (Mataram)"],
    "IR": ["Tahran (Tehran)", "İsfahan (Isfahan)", "Şiraz (Shiraz)", "Meşhed (Mashhad)", "Tebriz (Tabriz)", "Yazd", "Kum (Qom)"],
    "IQ": ["Bağdat (Baghdad)", "Basra (Basrah)", "Musul (Mosul)", "Erbil", "Necef (Najaf)", "Kerbela (Karbala)", "Süleymaniye (Sulaymaniyah)"],
    "IL": ["Kudüs (Jerusalem)", "Tel Aviv", "Hayfa (Haifa)", "Eilat", "Nasıra (Nazareth)", "Beer Şeva (Beersheba)"],
    "JP": ["Tokyo", "Osaka", "Kyoto", "Yokohama", "Nagoya", "Sapporo", "Fukuoka", "Hiroşima (Hiroshima)", "Nara", "Kobe", "Nagasaki", "Okinawa", "Kamakura", "Nikko"],
    "JO": ["Amman", "Petra (Wadi Musa)", "Akabe (Aqaba)", "İrbid (Irbid)", "Cerash (Jerash)"],
    "KZ": ["Astana", "Almatı (Almaty)", "Şimkent (Shymkent)", "Türkistan (Turkistan)", "Aktau"],
    "KW": ["Kuveyt (Kuwait City)", "Al Ahmadi", "Hawalli"],
    "KG": ["Bişkek (Bishkek)", "Oş (Osh)", "Karakol", "Çolpon-Ata (Issyk-Kul Gölü)"],
    "LA": ["Vientiane", "Luang Prabang", "Pakse", "Vang Vieng"],
    "LB": ["Beyrut (Beirut)", "Trablus (Tripoli)", "Sayda (Sidon)", "Baalbek", "Byblos"],
    "MY": ["Kuala Lumpur", "George Town (Penang)", "Johor Bahru", "Malakka (Malacca)", "Kota Kinabalu", "Kuching", "Langkawi"],
    "MV": ["Male", "Hulhumale", "Addu City"],
    "MN": ["Ulan Batur (Ulaanbaatar)", "Erdenet", "Darhan", "Karakorum"],
    "MM": ["Naypyidaw", "Yangon (Rangoon)", "Mandalay", "Bagan", "Nyaungshwe (İnle Gölü)"],
    "NP": ["Katmandu (Kathmandu)", "Pokhara", "Lalitpur", "Bhaktapur", "Chitwan"],
    "KP": ["Pyongyang", "Hamhung", "Chongjin"],
    "OM": ["Maskat (Muscat)", "Salalah", "Sohar", "Nizwa"],
    "PK": ["İslamabad (Islamabad)", "Karaçi (Karachi)", "Lahor (Lahore)", "Faysalabad (Faisalabad)", "Peşaver (Peshawar)", "Multan", "Rawalpindi", "Hunza"],
    "PS": ["Ramallah", "Gazze (Gaza)", "Beytüllahim (Bethlehem)", "Nablus", "Hebron"],
    "PH": ["Manila", "Cebu", "Davao", "Quezon City", "Boracay", "Palawan (Puerto Princesa)", "Baguio"],
    "QA": ["Doha", "Al Wakrah", "Al Rayyan"],
    "SA": ["Riyad (Riyadh)", "Cidde (Jeddah)", "Mekke (Mecca)", "Medine (Medina)", "Dammam", "Taif", "Ebha (Abha)"],
    "SG": ["Singapur (Singapore)"],
    "KR": ["Seul (Seoul)", "Busan", "İncheon (Incheon)", "Daegu", "Gwangju", "Jeju", "Daejeon"],
    "LK": ["Sri Jayawardenepura Kotte", "Kolombo (Colombo)", "Kandy", "Galle", "Ella", "Nuwara Eliya"],
    "SY": ["Şam (Damascus)", "Halep (Aleppo)", "Humus (Homs)", "Lazkiye (Latakia)", "Palmira (Palmyra)"],
    "TW": ["Taipei", "Kaohsiung", "Taichung", "Tainan", "Hualien"],
    "TJ": ["Duşanbe (Dushanbe)", "Hocend (Khujand)", "Bulunkul"],
    "TH": ["Bangkok", "Chiang Mai", "Phuket", "Pattaya", "Ayutthaya", "Krabi", "Koh Samui", "Chiang Rai"],
    "TL": ["Dili", "Baucau", "Maliana"],
    "TR": TR_PROVINCES,
    "TM": ["Aşkabat (Ashgabat)", "Türkmenabat (Turkmenabat)", "Mary", "Daşoguz (Dashoguz)"],
    "AE": ["Abu Dabi (Abu Dhabi)", "Dubai", "Şarja (Sharjah)", "Ras Al Khaimah", "Fucayra (Fujairah)", "Ayn (Al Ain)"],
    "UZ": ["Taşkent (Tashkent)", "Semerkant (Samarkand)", "Buhara (Bukhara)", "Hiva (Khiva)", "Nukus"],
    "VN": ["Hanoi", "Ho Chi Minh City (Saygon)", "Da Nang", "Hue", "Hoi An", "Ha Long", "Nha Trang", "Sapa"],
    "YE": ["Sana (Sanaa)", "Aden", "Taiz", "Hudeyde (Al Hudaydah)"],
})

# --- AVRUPA ---
CITIES.update({
    "AL": ["Tiran (Tirana)", "Durres", "Vlore", "Shkodra", "Berat", "Saranda"],
    "AD": ["Andorra la Vella", "Escaldes-Engordany"],
    "AT": ["Viyana (Vienna)", "Salzburg", "Innsbruck", "Graz", "Linz", "Hallstatt"],
    "BY": ["Minsk", "Gomel", "Brest", "Grodno", "Vitebsk"],
    "BE": ["Brüksel (Brussels)", "Bruges", "Antwerp", "Gent (Ghent)", "Leuven"],
    "BA": ["Saraybosna (Sarajevo)", "Mostar", "Banja Luka", "Tuzla"],
    "BG": ["Sofya (Sofia)", "Plovdiv", "Varna", "Burgas", "Veliko Tarnovo"],
    "HR": ["Zagreb", "Split", "Dubrovnik", "Rijeka", "Zadar", "Pula", "Hvar"],
    "CZ": ["Prag (Prague)", "Brno", "Cesky Krumlov", "Karlovy Vary", "Plzen"],
    "DK": ["Kopenhag (Copenhagen)", "Aarhus", "Odense", "Aalborg"],
    "EE": ["Talin (Tallinn)", "Tartu", "Narva", "Pärnu"],
    "FI": ["Helsinki", "Tampere", "Turku", "Rovaniemi", "Oulu"],
    "FR": ["Paris", "Marsilya (Marseille)", "Lyon", "Nice", "Toulouse", "Bordeaux", "Strasbourg", "Cannes", "Mont Saint-Michel", "Avignon", "Lille", "Nantes"],
    "DE": ["Berlin", "Münih (Munich)", "Hamburg", "Köln (Cologne)", "Frankfurt", "Stuttgart", "Dresden", "Nuremberg", "Heidelberg", "Düsseldorf", "Leipzig"],
    "GR": ["Atina (Athens)", "Selanik (Thessaloniki)", "Santorini", "Mikonos (Mykonos)", "Girit (Heraklion)", "Rodos (Rhodes)", "Korfu (Corfu)", "Meteora (Kalambaka)"],
    "HU": ["Budapeşte (Budapest)", "Debrecen", "Szeged", "Pecs", "Eger"],
    "IS": ["Reykjavik", "Akureyri", "Vik", "Keflavik"],
    "IE": ["Dublin", "Cork", "Galway", "Killarney", "Limerick"],
    "IT": ["Roma (Rome)", "Milano (Milan)", "Venedik (Venice)", "Floransa (Florence)", "Napoli (Naples)", "Torino (Turin)", "Bologna", "Verona", "Cinque Terre", "Pisa", "Palermo", "Como", "Positano", "Siena"],
    "XK": ["Priştine (Pristina)", "Prizren", "Peja"],
    "LV": ["Riga", "Daugavpils", "Jurmala", "Sigulda"],
    "LI": ["Vaduz", "Schaan"],
    "LT": ["Vilnius", "Kaunas", "Klaipeda", "Trakai"],
    "LU": ["Lüksemburg (Luxembourg City)", "Esch-sur-Alzette"],
    "MT": ["Valletta", "Sliema", "Mdina", "Gozo"],
    "MD": ["Kişinev (Chisinau)", "Tiraspol", "Balti"],
    "MC": ["Monako (Monaco-Ville)", "Monte Carlo"],
    "ME": ["Podgorica", "Kotor", "Budva", "Herceg Novi"],
    "NL": ["Amsterdam", "Rotterdam", "Lahey (The Hague)", "Utrecht", "Giethoorn", "Eindhoven", "Maastricht"],
    "MK": ["Üsküp (Skopje)", "Ohrid", "Bitola"],
    "NO": ["Oslo", "Bergen", "Trondheim", "Tromso", "Stavanger", "Lofoten"],
    "PL": ["Varşova (Warsaw)", "Krakow", "Gdansk", "Wroclaw", "Poznan", "Zakopane"],
    "PT": ["Lizbon (Lisbon)", "Porto", "Faro", "Sintra", "Madeira (Funchal)", "Coimbra"],
    "RO": ["Bükreş (Bucharest)", "Cluj-Napoca", "Timisoara", "Brasov", "Sibiu", "Constanta"],
    "RU": ["Moskova (Moscow)", "Saint Petersburg", "Kazan", "Soçi (Sochi)", "Novosibirsk", "Yekaterinburg", "Vladivostok"],
    "SM": ["San Marino", "Borgo Maggiore"],
    "RS": ["Belgrad (Belgrade)", "Novi Sad", "Nis", "Subotica"],
    "SK": ["Bratislava", "Kosice", "Zilina", "Tatra Dağları (High Tatras)"],
    "SI": ["Ljubljana", "Bled", "Piran", "Maribor"],
    "ES": ["Madrid", "Barselona (Barcelona)", "Sevilla (Seville)", "Valensiya (Valencia)", "Granada", "Malaga", "Bilbao", "San Sebastian", "Toledo", "Palma de Mallorca", "İbiza (Ibiza)", "Tenerife", "Kordoba (Cordoba)"],
    "SE": ["Stockholm", "Gothenburg", "Malmo", "Uppsala", "Kiruna"],
    "CH": ["Bern", "Zürih (Zurich)", "Cenevre (Geneva)", "Lucerne", "Interlaken", "Zermatt", "Basel"],
    "UA": ["Kiev (Kyiv)", "Lviv", "Odesa", "Harkiv (Kharkiv)", "Kamianets-Podilskyi"],
    "GB": ["Londra (London)", "Manchester", "Edinburgh", "Liverpool", "Glasgow", "Oxford", "Cambridge", "Bath", "Belfast", "Cardiff", "York"],
    "VA": ["Vatikan (Vatican City)"],
})

# --- KUZEY AMERİKA ---
CITIES.update({
    "AG": ["Saint John's", "All Saints"],
    "BS": ["Nassau", "Freeport", "Exuma"],
    "BB": ["Bridgetown", "Speightstown"],
    "BZ": ["Belmopan", "Belize City", "San Ignacio", "Placencia"],
    "CA": ["Ottava (Ottawa)", "Toronto", "Vancouver", "Montreal", "Calgary", "Quebec City", "Edmonton", "Winnipeg", "Niagara Falls", "Banff", "Halifax"],
    "CR": ["San Jose", "Liberia", "Puerto Viejo", "Manuel Antonio", "Monteverde"],
    "CU": ["Havana", "Santiago de Cuba", "Trinidad", "Varadero", "Vinales"],
    "DM": ["Roseau", "Portsmouth"],
    "DO": ["Santo Domingo", "Punta Cana", "Santiago", "Puerto Plata"],
    "SV": ["San Salvador", "Santa Ana", "La Libertad"],
    "GD": ["St. George's", "Grand Anse"],
    "GT": ["Guatemala City", "Antigua Guatemala", "Quetzaltenango", "Flores (Tikal)"],
    "HT": ["Port-au-Prince", "Cap-Haitien", "Jacmel"],
    "HN": ["Tegucigalpa", "San Pedro Sula", "Roatan", "Copan"],
    "JM": ["Kingston", "Montego Bay", "Ocho Rios", "Negril"],
    "MX": ["Meksiko (Mexico City)", "Guadalajara", "Monterrey", "Cancun", "Playa del Carmen", "Tulum", "Puebla", "Oaxaca", "Merida", "Los Cabos", "Puerto Vallarta", "Chihuahua", "Tijuana"],
    "NI": ["Managua", "Granada", "Leon", "San Juan del Sur"],
    "PA": ["Panama City", "Colon", "Bocas del Toro", "David"],
    "KN": ["Basseterre", "Charlestown"],
    "LC": ["Castries", "Soufriere"],
    "VC": ["Kingstown", "Bequia"],
    "TT": ["Port of Spain", "San Fernando", "Scarborough"],
    "US": ["Washington D.C.", "New York", "Los Angeles", "Chicago", "San Francisco", "Las Vegas", "Miami", "Boston", "Seattle", "Houston", "Orlando", "New Orleans", "Denver", "Honolulu", "Philadelphia", "Austin", "San Diego", "Nashville", "Grand Canyon Köyü (Grand Canyon Village)", "Anchorage"],
})

# --- GÜNEY AMERİKA ---
CITIES.update({
    "AR": ["Buenos Aires", "Cordoba", "Mendoza", "Bariloche", "El Calafate", "Ushuaia", "Salta", "Iguazu"],
    "BO": ["Sucre", "La Paz", "Santa Cruz", "Uyuni", "Potosi", "Cochabamba"],
    "BR": ["Brasilia", "Sao Paulo", "Rio de Janeiro", "Salvador", "Fortaleza", "Belo Horizonte", "Manaus", "Recife", "Florianopolis", "Curitiba", "Foz do Iguacu", "Porto Alegre"],
    "CL": ["Santiago", "Valparaiso", "San Pedro de Atacama", "Punta Arenas", "Puerto Varas", "Torres del Paine", "Easter Island (Rapa Nui)"],
    "CO": ["Bogota", "Medellin", "Cartagena", "Cali", "Santa Marta", "San Andres"],
    "EC": ["Quito", "Guayaquil", "Cuenca", "Galapagos (Puerto Ayora)", "Baños"],
    "GY": ["Georgetown", "Linden"],
    "PY": ["Asuncion", "Ciudad del Este", "Encarnacion"],
    "PE": ["Lima", "Cusco", "Machu Picchu (Aguas Calientes)", "Arequipa", "Puno", "Iquitos", "Trujillo"],
    "SR": ["Paramaribo", "Nieuw Nickerie"],
    "UY": ["Montevideo", "Punta del Este", "Colonia del Sacramento"],
    "VE": ["Karakas (Caracas)", "Maracaibo", "Merida", "Isla Margarita"],
})

# --- OKYANUSYA ---
CITIES.update({
    "AU": ["Canberra", "Sidney (Sydney)", "Melbourne", "Brisbane", "Perth", "Gold Coast", "Adelaide", "Cairns", "Darwin", "Hobart", "Uluru (Ayers Rock)"],
    "FJ": ["Suva", "Nadi", "Denarau Island"],
    "KI": ["Tarawa", "Betio"],
    "MH": ["Majuro", "Ebeye"],
    "FM": ["Palikir", "Weno"],
    "NR": ["Yaren"],
    "NZ": ["Wellington", "Auckland", "Queenstown", "Christchurch", "Rotorua", "Dunedin"],
    "PW": ["Ngerulmud", "Koror"],
    "PG": ["Port Moresby", "Lae", "Mount Hagen"],
    "WS": ["Apia", "Salelologa"],
    "SB": ["Honiara", "Auki"],
    "TO": ["Nuku'alofa", "Neiafu"],
    "TV": ["Funafuti"],
    "VU": ["Port Vila", "Luganville"],
})

# --- ANTARKTİKA (araştırma istasyonları) ---
CITIES.update({
    "AQ": ["McMurdo İstasyonu (McMurdo Station)", "Amundsen-Scott Güney Kutbu İstasyonu (Amundsen-Scott South Pole Station)", "Vostok İstasyonu (Vostok Station)", "Concordia İstasyonu (Concordia Station)", "Belgrano II İstasyonu (Belgrano II Station)", "Rothera İstasyonu (Rothera Station)", "Esperanza Üssü (Base Esperanza)"],
})


# ---------------------------------------------------------------------------
# 4) ÜRETİM MANTIĞI
# ---------------------------------------------------------------------------
def flag_emoji(iso2: str) -> str:
    """ISO2 koddan bölgesel gösterge sembolleriyle bayrak emojisi üretir."""
    if len(iso2) != 2 or not iso2.isalpha():
        return "🏳️"
    base = 0x1F1E6
    return "".join(chr(base + (ord(c.upper()) - ord("A"))) for c in iso2)


def slugify(text: str) -> str:
    """Şehir adını kararlı bir anahtar parçasına dönüştürür (aksan/boşluk temizler)."""
    # Parantez içindeki İngilizce adı at, sadece ilk kısmı kullan
    primary = text.split("(")[0].strip()
    normalized = unicodedata.normalize("NFKD", primary)
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    ascii_text = ascii_text.upper()
    ascii_text = re.sub(r"[^A-Z0-9]+", "_", ascii_text).strip("_")
    return ascii_text or "SEHIR"


def main():
    country_by_id = {c[0]: c for c in COUNTRIES}
    missing_cities = [iso for iso in country_by_id if iso not in CITIES]
    if missing_cities:
        raise SystemExit(f"Şehir listesi eksik olan ülkeler: {missing_cities}")

    extra_cities = [iso for iso in CITIES if iso not in country_by_id]
    if extra_cities:
        raise SystemExit(f"COUNTRIES listesinde olmayan ülke kodları CITIES içinde: {extra_cities}")

    # --- continents.json ---
    continents_out = [
        {"id": cid, "name_tr": name_tr, "name_en": name_en, "emoji": emoji}
        for (cid, name_tr, name_en, emoji) in CONTINENTS
    ]
    with open(os.path.join(OUT_DIR, "continents.json"), "w", encoding="utf-8") as f:
        json.dump(continents_out, f, ensure_ascii=False, indent=2)

    # --- countries.json ---
    countries_out = []
    for (iso2, name_tr, name_en, continent_id, capital) in COUNTRIES:
        countries_out.append({
            "id": iso2,
            "name_tr": name_tr,
            "name_en": name_en,
            "continent_id": continent_id,
            "capital": capital,
            "flag": flag_emoji(iso2),
        })
    countries_out.sort(key=lambda c: c["name_tr"])
    with open(os.path.join(OUT_DIR, "countries.json"), "w", encoding="utf-8") as f:
        json.dump(countries_out, f, ensure_ascii=False, indent=2)

    # --- provinces.json ---
    # Uygulama, bir ülkenin il/ilçe ara katmanı olup olmadığını bu dosyaya
    # bakarak (veri-tabanlı) karar verir. Şu an hiçbir ülke için il katmanı
    # kullanılmıyor (Türkiye dahil — ilçe ayrımından vazgeçildi, "şehir"
    # birimi doğrudan il oldu); dosya boş kalır ve tüm ülkeler eskisi gibi
    # düz şehir listesiyle gösterilir.
    provinces_out = []
    with open(os.path.join(OUT_DIR, "provinces.json"), "w", encoding="utf-8") as f:
        json.dump(provinces_out, f, ensure_ascii=False, indent=2)

    # --- cities.json ---
    cities_out = []
    total_cities = 0
    for iso2, names in CITIES.items():
        capital_name = country_by_id[iso2][4]
        capital_primary = capital_name.split("(")[0].strip()
        seen_keys = set()
        for name in names:
            key_body = slugify(name)
            key = f"{iso2}_{key_body}"
            # Aynı ülke içinde anahtar çakışmasını önle (nadiren aynı isim tekrarı)
            suffix = 2
            base_key = key
            while key in seen_keys:
                key = f"{base_key}_{suffix}"
                suffix += 1
            seen_keys.add(key)

            name_primary = name.split("(")[0].strip()
            is_capital = name_primary.lower() == capital_primary.lower()
            # Başkent olan şehirde parantez içeriği (varsa İngilizce karşılığı)
            # "(başkent)" etiketiyle değiştirilir; diğer şehirlerde olduğu gibi kalır.
            display_name = f"{name_primary} (başkent)" if is_capital else name

            cities_out.append({
                "key": key,
                "name": display_name,
                "country_id": iso2,
                "is_capital": is_capital,
                "province_id": None,
            })
            total_cities += 1

    with open(os.path.join(OUT_DIR, "cities.json"), "w", encoding="utf-8") as f:
        json.dump(cities_out, f, ensure_ascii=False, indent=2)

    print(f"Kıtalar: {len(continents_out)}")
    print(f"Ülkeler/bölgeler: {len(countries_out)}")
    print(f"Şehirler: {total_cities}")
    print(f"Ülke başına ortalama şehir: {total_cities / len(countries_out):.1f}")

    # Basit bütünlük kontrolü: her ülkenin en az 1 şehri olmalı
    counts_per_country = {}
    for c in cities_out:
        counts_per_country[c["country_id"]] = counts_per_country.get(c["country_id"], 0) + 1
    zero_city_countries = [iso for iso in country_by_id if counts_per_country.get(iso, 0) == 0]
    if zero_city_countries:
        raise SystemExit(f"Şehri olmayan ülkeler: {zero_city_countries}")

    print("Tüm ülkelerin en az 1 şehri var. ✅")


if __name__ == "__main__":
    main()

