#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SEYYAH logo ikonunu (klasik, üzerinde seyahat stickerları olan bir bavul,
kırmızı marka renginde) procedural olarak üretir.

Neden procedural: bu ortamda bir görsel üretim (image-generation) aracı
bulunmuyor, bu yüzden ikon Pillow ile düz (flat) vektörel şekillerden elle
çiziliyor. Kenarların pürüzsüz görünmesi için 4x supersample edilip
LANCZOS ile küçültülüyor (bkz. önceki sırt çantası ikonunun aynı tekniği).
"""
import math
from PIL import Image, ImageDraw

SS = 4  # supersample katsayısı
SIZE = 1024 * SS

RED = (227, 6, 19, 255)          # AppColors.seyyahRed
RED_DARK = (163, 4, 15, 255)     # AppColors.ink / seyyahRedDark ailesi
RED_DARKER = (120, 3, 11, 255)   # tekerlek / en koyu vurgu
WHITE = (255, 255, 255, 255)
TRANSPARENT = (0, 0, 0, 0)


def rounded_rect(draw, box, radius, fill):
    draw.rounded_rectangle(box, radius=radius, fill=fill)


def star_points(cx, cy, r_outer, r_inner, rotation_deg=-90):
    pts = []
    for i in range(10):
        angle = math.radians(rotation_deg + i * 36)
        r = r_outer if i % 2 == 0 else r_inner
        pts.append((cx + r * math.cos(angle), cy + r * math.sin(angle)))
    return pts


def heart_path(cx, cy, w, h):
    """Basit, dolu bir kalp şekli için Bezier tabanlı nokta listesi üretir."""
    pts = []
    steps = 60
    for i in range(steps + 1):
        t = (i / steps) * 2 * math.pi
        x = 16 * math.sin(t) ** 3
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((cx + x * (w / 34.0), cy + y * (h / 34.0)))
    return pts


def draw_sticker_disc(draw, cx, cy, r, ring_color=RED, fill=WHITE, ring_w=None):
    if ring_w is None:
        ring_w = max(2, int(r * 0.14))
    draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=ring_color)
    ri = r - ring_w
    draw.ellipse([cx - ri, cy - ri, cx + ri, cy + ri], fill=fill)


def draw_globe_sticker(draw, cx, cy, r):
    draw_sticker_disc(draw, cx, cy, r, ring_color=RED, fill=WHITE)
    gr = r * 0.72
    lw = max(2, int(r * 0.07))
    draw.ellipse([cx - gr, cy - gr, cx + gr, cy + gr], outline=RED, width=lw)
    # dikey meridyenler (elips olarak)
    for k in (0.36, 0.72):
        draw.ellipse([cx - gr * k, cy - gr, cx + gr * k, cy + gr], outline=RED, width=lw)
    # yatay paralel
    draw.line([cx - gr, cy, cx + gr, cy], fill=RED, width=lw)
    draw.line([cx - gr * 0.86, cy - gr * 0.5, cx + gr * 0.86, cy - gr * 0.5], fill=RED, width=lw)
    draw.line([cx - gr * 0.86, cy + gr * 0.5, cx + gr * 0.86, cy + gr * 0.5], fill=RED, width=lw)


def draw_star_sticker(draw, cx, cy, r):
    draw_sticker_disc(draw, cx, cy, r, ring_color=RED_DARK, fill=WHITE)
    pts = star_points(cx, cy, r * 0.62, r * 0.27)
    draw.polygon(pts, fill=RED_DARK)


def draw_heart_sticker(draw, cx, cy, r):
    draw_sticker_disc(draw, cx, cy, r, ring_color=RED, fill=WHITE)
    pts = heart_path(cx, cy - r * 0.05, r * 1.25, r * 1.25)
    draw.polygon(pts, fill=RED)


def draw_plane_sticker(draw, cx, cy, r):
    """Klasik kağıt uçak / 'gönder' oku silueti — burnu yukarı-sağı
    gösterecek şekilde 45 derece döndürülmüş bir ok (dart) şeklidir."""
    draw_sticker_disc(draw, cx, cy, r, ring_color=RED_DARK, fill=WHITE)
    s = r * 0.9
    local = [(1.0, 0.0), (-0.85, 0.55), (-0.25, 0.0), (-0.85, -0.55)]
    ang = math.radians(-45)
    ca, sa = math.cos(ang), math.sin(ang)
    pts = []
    for (lx, ly) in local:
        rx = lx * ca - ly * sa
        ry = lx * sa + ly * ca
        pts.append((cx + rx * s, cy + ry * s))
    draw.polygon(pts, fill=RED_DARK)
    # kanat kırışıklığı (orta katlama çizgisi)
    nose = pts[0]
    fold = pts[2]
    draw.line([nose, fold], fill=WHITE, width=max(2, int(s * 0.09)))


def draw_pin_sticker(draw, cx, cy, r):
    """Klasik konum/harita iğnesi (pin) stickerı."""
    draw_sticker_disc(draw, cx, cy, r, ring_color=RED, fill=WHITE)
    pr = r * 0.55
    pin_cy = cy - r * 0.12
    tip_y = cy + r * 0.62
    d_local = [
        (cx - pr, pin_cy),
        (cx, tip_y),
        (cx + pr, pin_cy),
    ]
    draw.ellipse([cx - pr, pin_cy - pr, cx + pr, pin_cy + pr], fill=RED)
    draw.polygon(d_local, fill=RED)
    hole_r = pr * 0.42
    draw.ellipse([cx - hole_r, pin_cy - hole_r, cx + hole_r, pin_cy + hole_r], fill=WHITE)


def main():
    img = Image.new("RGBA", (SIZE, SIZE), TRANSPARENT)
    d = ImageDraw.Draw(img)

    cx = SIZE / 2

    # ---- Bavul gövdesi (klasik, sandık/trunk tarzı hardshell bavul) ----
    body_left = SIZE * 0.20
    body_right = SIZE * 0.80
    body_top = SIZE * 0.30
    body_bottom = SIZE * 0.86
    body_radius = SIZE * 0.055
    rounded_rect(d, [body_left, body_top, body_right, body_bottom], body_radius, RED)
    lid_y = body_top + (body_bottom - body_top) * 0.14

    # ---- Üst tutamak (handle) ----
    handle_w = SIZE * 0.20
    handle_h = SIZE * 0.11
    handle_cx = cx
    handle_cy = body_top - handle_h * 0.42
    handle_outer = [handle_cx - handle_w / 2, handle_cy - handle_h / 2,
                    handle_cx + handle_w / 2, handle_cy + handle_h / 2]
    d.rounded_rectangle(handle_outer, radius=handle_h * 0.5, fill=RED_DARK)
    inner_pad = SIZE * 0.028
    handle_inner = [handle_outer[0] + inner_pad, handle_outer[1] + inner_pad,
                    handle_outer[2] - inner_pad, handle_outer[3] - inner_pad]
    d.rounded_rectangle(handle_inner, radius=(handle_h - 2 * inner_pad) * 0.5, fill=TRANSPARENT)

    # Tutamağın gövdeye bağlandığı köşe pernoları (rivets)
    rivet_r = SIZE * 0.022
    for rx in (handle_cx - handle_w * 0.46, handle_cx + handle_w * 0.46):
        d.ellipse([rx - rivet_r, body_top - rivet_r * 0.4,
                   rx + rivet_r, body_top + rivet_r * 1.6], fill=RED_DARK)

    # ---- Orta kemer/kayış (klasik bavul kayışı + toka) ----
    strap_h = SIZE * 0.085
    strap_y = body_top + (body_bottom - body_top) * 0.56
    d.rectangle([body_left - SIZE * 0.01, strap_y, body_right + SIZE * 0.01, strap_y + strap_h],
                fill=RED_DARK)
    buckle_w = SIZE * 0.11
    buckle_h = strap_h + SIZE * 0.02
    d.rounded_rectangle(
        [cx - buckle_w / 2, strap_y - SIZE * 0.01, cx + buckle_w / 2, strap_y + buckle_h - SIZE * 0.01],
        radius=SIZE * 0.012, outline=WHITE, width=max(3, int(SIZE * 0.009)))
    d.line([cx, strap_y - SIZE * 0.01, cx, strap_y + buckle_h - SIZE * 0.01], fill=WHITE,
           width=max(3, int(SIZE * 0.009)))

    # ---- Ayaklar (alt kenarda küçük destekler) ----
    foot_w = SIZE * 0.05
    foot_h = SIZE * 0.018
    for fx in (body_left + SIZE * 0.08, body_right - SIZE * 0.08):
        d.rounded_rectangle([fx - foot_w / 2, body_bottom - SIZE * 0.004,
                              fx + foot_w / 2, body_bottom + foot_h], radius=foot_h / 2, fill=RED_DARKER)

    # ---- Stickerlar (klasik seyahat etiketleri): globe, yıldız, kalp,
    # uçak ve konum iğnesi — gövdenin ortasındaki kemerin üstünde ve
    # altında iki sıra halinde, birbirine değmeyecek boşluklarla ----
    r_big = SIZE * 0.10
    r_small = SIZE * 0.075

    top_row_y = lid_y + (strap_y - lid_y) * 0.42
    draw_star_sticker(d, cx - SIZE * 0.20, top_row_y, r_small)
    draw_globe_sticker(d, cx, top_row_y - SIZE * 0.01, r_big)
    draw_heart_sticker(d, cx + SIZE * 0.20, top_row_y, r_small)

    bottom_row_y = strap_y + strap_h + (body_bottom - (strap_y + strap_h)) * 0.42
    draw_plane_sticker(d, cx - SIZE * 0.155, bottom_row_y, r_small)
    draw_pin_sticker(d, cx + SIZE * 0.155, bottom_row_y, r_small)

    # Downscale (anti-aliasing)
    final_size = 1024
    img = img.resize((final_size, final_size), Image.LANCZOS)
    return img


if __name__ == "__main__":
    icon = main()
    icon.save("/home/claude/seyyah/preview/suitcase_preview.png")
    print("Kaydedildi: preview/suitcase_preview.png")
