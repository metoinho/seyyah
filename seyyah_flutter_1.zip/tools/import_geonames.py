#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GeoNames şehir verisini SEYYAH'ın `assets/data/cities.json` dosyasına
İÇE AKTARIR (import). Bu, kullanıcının ileride başlangıç veri setini
(bkz. `generate_data.py`) çok daha kapsamlı, resmi bir kaynakla
(GeoNames — CC BY 4.0 lisanslı, https://www.geonames.org) genişletmesini
sağlayan isteğe bağlı bir araçtır.

KULLANIM:
  1) https://download.geonames.org/export/dump/ adresinden bir şehir
     dökümü indirin, örn. "cities15000.zip" (nüfusu >=15.000 olan şehirler,
     ~25 bin satır) veya daha kapsamlı "cities5000.zip" / "cities1000.zip".
  2) Zip'i açın (içinden .txt dosyası çıkar, tab (\t) ile ayrılmıştır).
  3) Bu script'i çalıştırın:

       python3 tools/import_geonames.py /yol/cities15000.txt \
           --min-population 20000 \
           --max-per-country 60

     Bu komut, assets/data/cities.json dosyasını GÜNCELLER: var olan
     şehirler (ve onların is_capital bilgisi) korunur, uygun yeni şehirler
     eklenir. Ardından uygulamanın veritabanı seed sürümünü artırmak için
     `lib/data/database_helper.dart` içindeki `_seedDataVersion` sabitini
     bir üst değere çekmeyi UNUTMAYIN — aksi halde mevcut kullanıcıların
     cihazındaki veritabanı yeni şehirleri görmez (bu, kullanıcıların
     "gezildi" işaretlerini kaybetmemesi için bilinçli bir güvenlik önlemidir).

GeoNames dosya biçimi (tab ile ayrılmış, başlıksız), ilgili alan indeksleri:
  0 geonameid, 1 name, 2 asciiname, 3 alternatenames, 4 latitude,
  5 longitude, 6 feature class, 7 feature code, 8 country code,
  9 cc2, 10 admin1 code, 11 admin2 code, 12 admin3 code, 13 admin4 code,
  14 population, 15 elevation, 16 dem, 17 timezone, 18 modification date
"""
import argparse
import json
import os
import re
import sys
import unicodedata
from collections import defaultdict

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CITIES_JSON = os.path.join(BASE, "assets", "data", "cities.json")
COUNTRIES_JSON = os.path.join(BASE, "assets", "data", "countries.json")


def slugify(text: str) -> str:
    normalized = unicodedata.normalize("NFKD", text)
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii").upper()
    ascii_text = re.sub(r"[^A-Z0-9]+", "_", ascii_text).strip("_")
    return ascii_text or "SEHIR"


def load_known_country_ids():
    with open(COUNTRIES_JSON, encoding="utf-8") as f:
        countries = json.load(f)
    return {c["id"] for c in countries}


def load_existing_cities():
    with open(CITIES_JSON, encoding="utf-8") as f:
        return json.load(f)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("geonames_file", help="GeoNames .txt döküm dosyasının yolu (tab ile ayrılmış)")
    parser.add_argument("--min-population", type=int, default=15000,
                         help="Bu nüfusun altındaki yerleşimler atlanır (varsayılan: 15000)")
    parser.add_argument("--max-per-country", type=int, default=200,
                         help="Ülke başına eklenecek en fazla YENİ şehir sayısı (varsayılan: 200)")
    parser.add_argument("--dry-run", action="store_true", help="Dosyaya yazma, sadece özet göster")
    args = parser.parse_args()

    known_countries = load_known_country_ids()
    existing = load_existing_cities()
    existing_keys = {c["key"] for c in existing}
    # Aynı şehri (isim bazında) tekrar eklememek için ülke+normalize-isim seti
    existing_names = {(c["country_id"], slugify(c["name"].split("(")[0])) for c in existing}

    new_count_per_country = defaultdict(int)
    added = []

    if not os.path.exists(args.geonames_file):
        print(f"HATA: Dosya bulunamadı: {args.geonames_file}", file=sys.stderr)
        sys.exit(1)

    with open(args.geonames_file, encoding="utf-8") as f:
        for line in f:
            cols = line.rstrip("\n").split("\t")
            if len(cols) < 15:
                continue
            name = cols[1].strip()
            country_code = cols[8].strip().upper()
            feature_class = cols[6].strip()
            try:
                population = int(cols[14]) if cols[14] else 0
            except ValueError:
                population = 0

            if feature_class != "P":
                continue
            if country_code not in known_countries:
                continue
            if population < args.min_population:
                continue
            if new_count_per_country[country_code] >= args.max_per_country:
                continue

            name_key = slugify(name)
            if (country_code, name_key) in existing_names:
                continue

            key = f"{country_code}_{name_key}"
            suffix = 2
            base_key = key
            while key in existing_keys:
                key = f"{base_key}_{suffix}"
                suffix += 1

            entry = {
                "key": key,
                "name": name,
                "country_id": country_code,
                "is_capital": False,
            }
            added.append(entry)
            existing_keys.add(key)
            existing_names.add((country_code, name_key))
            new_count_per_country[country_code] += 1

    print(f"Eklenecek yeni şehir sayısı: {len(added)}")
    print(f"Etkilenen ülke sayısı: {len(new_count_per_country)}")
    if args.dry_run:
        print("(--dry-run: dosyaya yazılmadı)")
        return

    merged = existing + added
    with open(CITIES_JSON, "w", encoding="utf-8") as f:
        json.dump(merged, f, ensure_ascii=False, indent=2)

    print(f"Güncellendi: {CITIES_JSON}")
    print(f"Toplam şehir sayısı: {len(merged)}")
    print("")
    print("ÖNEMLİ: lib/data/database_helper.dart içindeki _seedDataVersion "
          "değerini artırmayı unutmayın (ör. '1' -> '2'), aksi halde mevcut "
          "kullanıcıların cihazlarında yeni şehirler görünmez.")


if __name__ == "__main__":
    main()
